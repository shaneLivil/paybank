<?php
/*
	header('Content-type: text/html; charset=utf-8');
	header("Content-type:application/vnd.ms-excel");
	header("Content-type: application/vnd.ms-excel; charset=euc-kr");
	header("Content-Disposition:filename=test.xls");

	$strexport="CardNumber\tCardNumberHexadecimal\tCardNumberMD5\tPassword\tCardPass16\tCardColor\tCardVersion\r";
	$strexport .= "6222215838120900\t";
	$strexport .= "007\t";
	$strexport .= "05\r";
	$strexport_a = iconv('UTF-8','EUC-KR',$strexport);
	exit($strexport_a);
*/

	header('Content-type: text/html; charset=utf-8');
 header("Content-type:application/vnd.ms-excel");
 header("Content-type: application/vnd.ms-excel; charset=euc-kr");
 header("Content-Disposition:filename=test.xls");    
 $strexport ="<table border='1' width='100%'>";
 $strexport .= "<tr>";
 $strexport .= "<td style='vnd.ms-excel.numberformat:@'>6222215838120900\t</td>";
 $strexport .= "<td style='vnd.ms-excel.numberformat:@'>007\t</td>";
 $strexport .= "<td style='vnd.ms-excel.numberformat:@'>05\r</td>";
 $strexport .= "</tr>";
 $strexport .= "</table>";
 $strexport_a = iconv('UTF-8','EUC-KR',$strexport);
 exit($strexport_a);
		
?>