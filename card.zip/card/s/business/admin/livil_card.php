<?php
	include '../db/dbconfig.php';
	header('Content-Type: text/html; charset=UTF-8');
	date_default_timezone_set("Asia/Shanghai");
	$data = file_get_contents('php://input');

	if($data){
		if($conn){
			$jsonArr= json_decode($data,TRUE);
			$merchantOrderNum = $jsonArr['merchantOrderNum'];
			$time = time();

			$sql_update = " UPDATE `billing_history` SET `status` = 1,`update_time` = '".$time."' WHERE `ordernum` = '".$merchantOrderNum."' ";
			mysqli_query($conn, $sql_update);
			echo "SUCCESS";
		}else{ echo "FAIL"; }
	}else{ echo "잘못된 접근입니다."; }
?>