<?php
	header('Content-type: text/html; charset=utf-8');
	include '../db/dbconfig.php';

	if($conn){
		$result = $_POST['result'];

		if($result == "card_download"){
			$card_version = $_POST['card_version'];
			$file_name = $_POST['file_name'];

			$sql_select = " SELECT `pk_id`,`card_number`,`card_number_16`,`card_number_md`,`password`,`card_password_16`,`card_color`,`card_version`,`company_name` FROM `card_history` WHERE `card_version` = '".$card_version."' ORDER BY `pk_id` ASC ";
			$result = mysqli_query($conn, $sql_select);
			header("Content-type:application/vnd.ms-excel");
			header("Content-type: application/vnd.ms-excel; charset=euc-kr");
			header("Content-Disposition:filename=".$file_name.".xls");
			$strexport = "";
			$strexport .="<table border='1' width='100%'>";
			$strexport .= "<tr>";
			$strexport .= "<td style='vnd.ms-excel.numberformat:@'>卡号</td>";
			$strexport .= "<td style='vnd.ms-excel.numberformat:@'>卡密(一次MD5加密)</td>";
			$strexport .= "<td style='vnd.ms-excel.numberformat:@'>16进制字符串</td>";
			$strexport .= "<td style='vnd.ms-excel.numberformat:@'>备注</td>";
			$strexport .= "</tr>";
			while($row = mysqli_fetch_array($result)){
				$aaa = str_replace("B--", "", $row['card_number']);
				$strexport .= "<tr>";
				$strexport .= "<td style='vnd.ms-excel.numberformat:@'>".$aaa."</td>";
				$strexport .= "<td style='vnd.ms-excel.numberformat:@'>".$row['password']."</td>";
				$strexport .= "<td style='vnd.ms-excel.numberformat:@'>".$row['card_password_16']."</td>";
				$strexport .= "<td style='vnd.ms-excel.numberformat:@'>".$row['company_name']."</td>";
				$strexport .= "</tr>";
			}
			$strexport .= "</table>";
			$strexport_a = iconv('UTF-8','UTF-8',$strexport);
			exit($strexport_a);
		}
	}else{
		echo "서버 에러. 잠시후 다시 시도하세요.";
	}
?>