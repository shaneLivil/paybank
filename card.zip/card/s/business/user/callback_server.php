<?php
	$result = $_POST['result'];

	if($result == "u_add_payment"){
		include '../db/dbconfig.php';
		$appKey = "kp5788f0a33be4414bb4a51a94cc136e40";
		$appSecret = "s84fe6de7923b470d9281b14896d24bb7";
		$time = time();
		$currencyType = 2;                                 // (1: CNY 2: USD 3: KWR)
		$pk_id = $_POST['pk_id'];                          // 업체 고유값
		$company_name = $_POST['company_name'];            // 업체 상호
		$company_contact = $_POST['company_contact'];      // 업체 연락처
		$company_number = $_POST['company_number'];        // 사업자 번호
		$itemname = $_POST['itemname'];                    // 카드유형(월렛카드)
		$card_color = $_POST['card_color'];                // 카드색상(blue or red)
		$card_number = $_POST['card_number'];              // 카드장수(100 ~ 5000장)
		$total_price = $_POST['total_price'];              // 카드 총가격(카드장수 + 단가)
		$orderNum = $time.$pk_id;                          // 주문번호(时间戳 + 업체고유값)
		$qrcodetype = "1";

		if($conn){
			$sql_select = " SELECT `pk_id` FROM `company` WHERE `pk_id` = ".$pk_id." ";
			$result = mysqli_query($conn, $sql_select);
			$row = mysqli_fetch_array($result);

			if($row['pk_id']){
				$sign = md5("AMOUNT=".$total_price."&APPKEY=".$appKey."&CURRENCYTYPE=".$currencyType."&GOODSNAME=".$itemname."&MERCHANTORDERNUM=".$orderNum."&QRCODETYPE=".$qrcodetype."&TS=".$time."&APPSECRET=".$appSecret); 
				$sign = strtolower($sign);
				   
				$value = array(
					"amount" => $total_price,
					"appKey" => $appKey,
					"currencyType" => $currencyType,
					"goodsName" => $itemname,
					"merchantOrderNum" => $orderNum,
					"qrCodeType" => $qrcodetype,
					"ts" => $time,
					"sign" => $sign
				);
				$value = json_encode($value);

				$sql_insert = " INSERT INTO `billing_history` (`pk_id`,`company_pk_id`,`company_name`,`company_contact`,`company_number`,`itemname`,`card_color`,`card_number`,`type`,`price`,`status`,`ordernum`,`sign`,`order_value`,`insert_time`,`update_time`,`admin_status`) VALUES ";
				$sql_insert .= " (NULL,".$pk_id.",'".$company_name."','".$company_contact."','".$company_number."','".$itemname."','".$card_color."','".$card_number."','PAX',".$total_price.",0,'".$orderNum."','".$sign."','".$value."','".$time."','".$time."',0) ";
				mysqli_query($conn, $sql_insert);
			}else{
				$value = array(
					"reten" => "fail"
				);
				$value = json_encode($value);
			}
		}else{
			$value = array(
				"reten" => "fail"
			);
			$value = json_encode($value);
		}
		echo $value;
	}
?>