<?php
	include './db/dbconfig.php';
    // date_default_timezone_set('Asia/Seoul');
	header('Content-Type: text/html; charset=UTF-8');
    date_default_timezone_set("Asia/Shanghai");
	$result = $_POST['result'];
	$http_url = "http://agent.paybank.com/business/conn_database.php";
	
	if($result == "login"){
		if($conn){
			$user_id = $_POST['user_id'];
			$password = mysql_new_password($_POST['password']);

			$sql_select = " SELECT `pk_id` FROM `admin` WHERE `user_id` = '".$user_id."' AND `password` = '".$password."' ";
			$result = mysqli_query($conn, $sql_select);
			$row = mysqli_fetch_array($result);

			if($row['pk_id']){
				setcookie("p_mobile",$user_id,0,"/",".livilcard.com");
				setcookie("p_password",$password,0,"/",".livilcard.com");
				setcookie("p_code",$row['pk_id'],0,"/",".livilcard.com");
				$arr = array(
					"code" => 1,
					"message" => "SUCC"
				);
			}else{
				$arr = array(
					"code" => 0,
					"message" => "NO"
				);
			}
		}else{
			$arr = array(
				"code" => 0,
				"message" => "FAIL"
			);
		}
		$arr = json_encode($arr, JSON_UNESCAPED_UNICODE);
		echo $arr;
	}else if($result == 'ck_cookie'){
		if($conn){
			$sql_select = " SELECT * FROM `admin` WHERE `pk_id` = ".$_COOKIE["p_code"]." AND `user_id` = '".$_COOKIE["p_mobile"]."' AND `password` = '".$_COOKIE["p_password"]."' ";
			$result = mysqli_query($conn, $sql_select);
			$row = mysqli_fetch_array($result);
			
			if($row['pk_id']){
				$arr = array(
					"code" => 1,
					"card_unit_price" => $row['card_unit_price'],
					"message" => $row['pk_id']
				);
			}else{
				$arr = array(
					"code" => 0,
					"message" => "NO"
				);
			}
		}else{
			$arr = array(
				"code" => 0,
				"message" => "FAIL"
			);
		}
		$arr = json_encode($arr, JSON_UNESCAPED_UNICODE);
		echo $arr;
	}else if($result == 'logout'){
		setcookie("p_mobile",null,-1,"/",".livilcard.com");
		setcookie("p_password",null,-1,"/",".livilcard.com");
		setcookie("p_code",null,-1,"/",".livilcard.com");
		$arr = array(
			"code" => 1,
			"message" => "SUCC"
		);
		$arr = json_encode($arr, JSON_UNESCAPED_UNICODE);
		echo $arr;
	}else if($result == 'a_add_card'){
		if($conn){
			$card_color_type = $_POST['card_color_type'];
			$card_number = $_POST['card_number'];
			$card_version = $_POST['card_version'];
			$card_english = $_POST['card_english'];

			$sql_select = " SELECT `card_version` FROM `card_history` WHERE `card_version` = '".$card_version."' LIMIT 1 ";
			$result = mysqli_query($conn, $sql_select);
			$row = mysqli_fetch_array($result);

			if($row['card_version']){
				$arr = array(
					"code" => 0,
					"message" => "YOU"
				);
			}else{
				if($card_number > 5000){
					$arr = array(
						"code" => 0,
						"message" => "EX"
					);
				}else{
					$sql_insert = " INSERT INTO `card_history` (`pk_id`,`card_number`,`card_number_16`,`card_number_md`,`password`,`card_password_16`,`card_color`,`card_version`,`status`,`insert_time`,`update_time`,`company_id`,`company_name`,`issued_time`) VALUES ";
					for($i=0; $i<$card_number; $i++){
						$rand_num = sprintf('%03d',rand(000,999));
						$time = time();
						$card_order = $time.$i;
						$card = "";
		
						if(strlen($card_order) == 11){ $card = "62222".$card_order; }
						else if(strlen($card_order) == 12){ $card = "6222".$card_order; }
						else if(strlen($card_order) == 13){ $card = "622".$card_order; }
						else if(strlen($card_order) == 14){ $card = "62".$card_order; }
						else if(strlen($card_order) == 15){ $card = "6".$card_order; }
						$card = $card_english."-".$card;
		
						$card_hex = strToHex($card);    // 16진수 변환된것
						$card_md5 = md5($card);         // md5 암호화
						$card_password = strToHex($card.$rand_num);   // 카드번호 + 비밀번호 16진수 변환된것
						$card_password = $card_password."000000000000000000000000000000000000000000000000000000";
						$sql_insert .= "(NULL,'".$card."','".$card_hex."','".$card_md5."','".$rand_num."','".$card_password."','".$card_color_type."','".$card_version."',0,'".$time."','".$time."',0,'','".$time."'),";
					}
					$sql_insert = substr($sql_insert, 0, -1);
					$sql_insert .= ";";
					mysqli_query($conn, $sql_insert);
					
					$arr = array(
						"code" => 1,
						"message" => "SUCC"
					);
				}
			}
		}else{
			$arr = array(
				"code" => 0,
				"message" => "FAIL"
			);
		}
		$arr = json_encode($arr, JSON_UNESCAPED_UNICODE);
		echo $arr;
	}else if($result == 'a_card_history_count'){
		if($conn){
			$status = $_POST['status'];
			$card_color = $_POST['card_color'];
			$card_number = $_POST['card_number'];
			$company_version = $_POST['company_version'];
			$company_name = $_POST['company_name'];
			$start_date_id = strtotime($_POST['start_date_id']);
			$stop_date_id = $_POST['stop_date_id'];
			if($stop_date_id != ""){ $stop_date_id = strtotime($stop_date_id." 23:59:59"); }
			$start_date_u = strtotime($_POST['start_date_u']);
			$stop_date_u = $_POST['stop_date_u'];
			if($stop_date_u != ""){ $stop_date_u = strtotime($stop_date_u." 23:59:59"); }

			$sql_select = " SELECT COUNT(*) AS `count` FROM `card_history` WHERE `pk_id` != '' ";
			if($status != 9 && $status != ""){ $sql_select .= " AND `status` = ".$status." "; }
			if($card_color != "all" && $card_color != ""){ $sql_select .= " AND `card_color` = '".$card_color."' "; }
			if($company_version != ""){ $sql_select .= " AND `card_version` = '".$company_version."' "; }
			if($card_number != ""){ $sql_select .= " AND `card_number` = '".$card_number."' "; }
			if($company_name != ""){ $sql_select .= " AND `company_name` = '".$company_name."' "; }
			if($start_date_id != ""){ $sql_select .= " AND `insert_time` > '".$start_date_id."' "; }
			if($stop_date_id != ""){ $sql_select .= " AND `insert_time` < '".$stop_date_id."' "; }
			if($start_date_u != ""){ $sql_select .= " AND `update_time` > '".$start_date_u."' "; }
			if($stop_date_u != ""){ $sql_select .= " AND `update_time` < '".$stop_date_u."' "; }
			$data = mysqli_query($conn, $sql_select);
			$row_2 = mysqli_fetch_array($data);
			if($row_2['count'] == 0){
				$arr = array(
					"code" => 0,
					"message" => "NoData"
				);
			}else{
				$arr = array(
					"code" => 1,
					"message" => $row_2['count']
				);
			}
		}else{
			$arr = array(
				"code" => 0,
				"message" => "FAIL"
			);
		}
		$arr = json_encode($arr, JSON_UNESCAPED_UNICODE);
		echo $arr;
	}else if($result == 'a_card_history'){
		if($conn){
			$status = $_POST['status'];
			$card_color = $_POST['card_color'];
			$card_number = $_POST['card_number'];
			$company_name = $_POST['company_name'];
			$company_version = $_POST['company_version'];
			$start_date_id = strtotime($_POST['start_date_id']);
			$stop_date_id = $_POST['stop_date_id'];
			if($stop_date_id != ""){ $stop_date_id = strtotime($stop_date_id." 23:59:59"); }
			$start_date_u = strtotime($_POST['start_date_u']);
			$stop_date_u = $_POST['stop_date_u'];
			if($stop_date_u != ""){ $stop_date_u = strtotime($stop_date_u." 23:59:59"); }
			$s_data = $_POST['s_data'];
			$e_data = $_POST['e_data'];

			$sql_select = " SELECT * FROM `card_history` WHERE `pk_id` != '' ";
			if($status != 9 && $status != ""){ $sql_select .= " AND `status` = ".$status." "; }
			if($card_color != "all" && $card_color != ""){ $sql_select .= " AND `card_color` = '".$card_color."' "; }
			if($company_version != ""){ $sql_select .= " AND `card_version` = '".$company_version."' "; }
			if($card_number != ""){ $sql_select .= " AND `card_number` = '".$card_number."' "; }
			if($company_name != ""){ $sql_select .= " AND `company_name` = '".$company_name."' "; }
			if($start_date_id != ""){ $sql_select .= " AND `insert_time` > '".$start_date_id."' "; }
			if($stop_date_id != ""){ $sql_select .= " AND `insert_time` < '".$stop_date_id."' "; }
			if($start_date_u != ""){ $sql_select .= " AND `update_time` > '".$start_date_u."' "; }
			if($stop_date_u != ""){ $sql_select .= " AND `update_time` < '".$stop_date_u."' "; }
			$sql_select .= " ORDER BY `pk_id` DESC LIMIT ".$s_data.", ".$e_data." ";
			$result = mysqli_query($conn, $sql_select);
			while($row = mysqli_fetch_array($result)){
				$res_list[] = array(
					"pk_id" => $row['pk_id'],
					"card_number" => $row['card_number'],
					"password" => $row['password'],
					"card_color" => $row['card_color'],
					"card_version" => $row['card_version'],
					"status" => $row['status'],
					"insert_time" => $row['insert_time'],
					"update_time" => $row['update_time'],
					"company_id" => $row['company_id'],
					"company_name" => $row['company_name']
				);
			}
			$res_list = json_encode($res_list, JSON_UNESCAPED_UNICODE);
			if($res_list == "null"){
				$arr = array(
					"code" => 0,
					"message" => "NoData"
				);
			}else{
				$arr = array(
					"code" => 1,
					"message" => $res_list
				);
			}
		}else{
			$arr = array(
				"code" => 0,
				"message" => "FAIL"
			);
		}
		$arr = json_encode($arr, JSON_UNESCAPED_UNICODE);
		echo $arr;
	}else if($result == 'a_add_company'){
		if($conn){
			$company_name = $_POST['company_name'];
			$company_contact = $_POST['company_contact'];
			$company_number = $_POST['company_number'];
			$password = mysql_new_password("1234");
			$time = time();
			
			$sql_select = " SELECT `pk_id` FROM `company` WHERE `company_number` = '".$company_number."' ";
			$result = mysqli_query($conn, $sql_select);
			$row = mysqli_fetch_array($result);

			if($row['pk_id']){
				$arr = array(
					"code" => 0,
					"message" => "YOU"
				);
			}else{
				$sql_insert = " INSERT INTO `company` (`pk_id`,`company_name`,`company_contact`,`company_number`,`insert_time`,`password`) VALUES ";
				$sql_insert .= " (NULL,'".$company_name."','".$company_contact."','".$company_number."','".$time."','".$password."') ";
				mysqli_query($conn, $sql_insert);

				$arr = array(
					"code" => 1,
					"message" => "SUCC"
				);
			}
		}else{
			$arr = array(
				"code" => 0,
				"message" => "FAIL"
			);
		}
		$arr = json_encode($arr, JSON_UNESCAPED_UNICODE);
		echo $arr;
	}else if($result == 'a_company_list_count'){
		if($conn){
			$company_pk_id = $_POST['company_pk_id'];
			$company_name = $_POST['company_name'];
			$company_contact = $_POST['company_contact'];
			$company_number = $_POST['company_number'];

			$sql_select = " SELECT COUNT(*) AS `count` FROM `company` WHERE `pk_id` != '' ";
			if($company_pk_id != ""){ $sql_select .= " AND `pk_id` = ".$company_pk_id." "; }
			if($company_name != ""){ $sql_select .= " AND `company_name` = '".$company_name."' "; }
			if($company_contact != ""){ $sql_select .= " AND `company_contact` = '".$company_contact."' "; }
			if($company_number != ""){ $sql_select .= " AND `company_number` = '".$company_number."' "; }
			$data = mysqli_query($conn, $sql_select);
			$row_2 = mysqli_fetch_array($data);
			if($row_2['count'] == 0){
				$arr = array(
					"code" => 0,
					"message" => "NoData"
				);
			}else{
				$arr = array(
					"code" => 1,
					"message" => $row_2['count']
				);
			}
		}else{
			$arr = array(
				"code" => 0,
				"message" => "FAIL"
			);
		}
		$arr = json_encode($arr, JSON_UNESCAPED_UNICODE);
		echo $arr;
	}else if($result == 'a_company_list'){
		if($conn){
			$company_pk_id = $_POST['company_pk_id'];
			$company_name = $_POST['company_name'];
			$company_contact = $_POST['company_contact'];
			$company_number = $_POST['company_number'];
			$s_data = $_POST['s_data'];
			$e_data = $_POST['e_data'];

			$sql_select = " SELECT * FROM `company` WHERE `pk_id` != '' ";
			if($company_pk_id != ""){ $sql_select .= " AND `pk_id` = ".$company_pk_id." "; }
			if($company_name != ""){ $sql_select .= " AND `company_name` = '".$company_name."' "; }
			if($company_contact != ""){ $sql_select .= " AND `company_contact` = '".$company_contact."' "; }
			if($company_number != ""){ $sql_select .= " AND `company_number` = '".$company_number."' "; }
			$sql_select .= " ORDER BY `pk_id` DESC LIMIT ".$s_data.", ".$e_data." ";
			$result = mysqli_query($conn, $sql_select);
			while($row = mysqli_fetch_array($result)){
				$res_list[] = array(
					"pk_id" => $row['pk_id'],
					"company_name" => $row['company_name'],
					"company_contact" => $row['company_contact'],
					"company_number" => $row['company_number'],
					"insert_time" => $row['insert_time'],
					"card_unit_price" => $row['card_unit_price'],
					"card_visa_1" => $row['card_visa_1'],
					"card_visa_2" => $row['card_visa_2'],
					"terminal_price" => $row['terminal_price'],
					"terminal_goout" => $row['terminal_goout']
				);
			}
			$res_list = json_encode($res_list, JSON_UNESCAPED_UNICODE);
			if($res_list == "null"){
				$arr = array(
					"code" => 0,
					"message" => "NoData"
				);
			}else{
				$arr = array(
					"code" => 1,
					"message" => $res_list
				);
			}
		}else{
			$arr = array(
				"code" => 0,
				"message" => "FAIL"
			);
		}
		$arr = json_encode($arr, JSON_UNESCAPED_UNICODE);
		echo $arr;
	}else if($result == 'select_company'){
		if($conn){
			$sql_select = " SELECT `pk_id`,`company_name`,`company_number` FROM `company` ";
			$result = mysqli_query($conn, $sql_select);
			while($row = mysqli_fetch_array($result)){
				$res_list[] = array(
					"pk_id" => $row['pk_id'],
					"company_name" => $row['company_name'],
					"company_number" => $row['company_number']
				);
			}
			$res_list = json_encode($res_list, JSON_UNESCAPED_UNICODE);
			if($res_list == "null"){
				$arr = array(
					"code" => 0,
					"message" => "NoData"
				);
			}else{
				$arr = array(
					"code" => 1,
					"message" => $res_list
				);
			}
		}else{
			$arr = array(
				"code" => 0,
				"message" => "FAIL"
			);
		}
		$arr = json_encode($arr, JSON_UNESCAPED_UNICODE);
		echo $arr;
	}else if($result == 'a_add_payment'){
		if($conn){
			$i_company = $_POST['i_company'];          // 업체 고유값
			$i_itemname = $_POST['i_itemname'];        // 카드유형
			$i_card_color = $_POST['i_card_color'];    // 카드색상
			$i_card_number = $_POST['i_card_number'];  // 카드장수
			$total_price = $_POST['total_price'];      // 금액(기준달러)

			$sql_select = " SELECT `pk_id`,`company_name`,`company_contact`,`company_number` FROM `company` WHERE `pk_id` = ".$i_company." ";
			$result = mysqli_query($conn, $sql_select);
			$row = mysqli_fetch_array($result);
			$time = time();
			$ordernum = $time.$i_company;              // 주문번호(时间戳 + 업체고유값)

			if($row['pk_id']){
				$sql_insert = " INSERT INTO `billing_history` (`pk_id`,`company_pk_id`,`company_name`,`company_contact`,`company_number`,`itemname`,`card_color`,`card_number`,`type`,`price`,`status`,`ordernum`,`sign`,`order_value`,`insert_time`,`update_time`,`admin_status`) VALUES ";
				$sql_insert .= " (NULL,".$i_company.",'".$row['company_name']."','".$row['company_contact']."','".$row['company_number']."','".$i_itemname."','".$i_card_color."',".$i_card_number.",'PAX',".$total_price.",1,'".$ordernum."',' ',' ','".$time."','".$time."',0) ";
				mysqli_query($conn, $sql_insert);
				$arr = array(
					"code" => 1,
					"message" => "SUCC"
				);
			}else{
				$arr = array(
					"code" => 0,
					"message" => "NO"
				);
			}
		}else{
			$arr = array(
				"code" => 0,
				"message" => "FAIL"
			);
		}
		$arr = json_encode($arr, JSON_UNESCAPED_UNICODE);
		echo $arr;
	}else if($result == 'card_xls_download'){
		if($conn){
			$d_card_version = $_POST['d_card_version'];
			$sql_select = " SELECT `card_version` FROM `card_history` WHERE `card_version` = '".$d_card_version."' LIMIT 1 ";
			$result = mysqli_query($conn, $sql_select);
			$row = mysqli_fetch_array($result);

			if($row['card_version']){
				$arr = array(
					"code" => 1,
					"message" => "SUCC"
				);
			}else{
				$arr = array(
					"code" => 0,
					"message" => "NO"
				);
			}
		}else{
			$arr = array(
				"code" => 0,
				"message" => "FAIL"
			);
		}
		$arr = json_encode($arr, JSON_UNESCAPED_UNICODE);
		echo $arr;
	}else if($result == 'a_payment_history_count'){
		if($conn){
			$company_pk_id = $_POST['company_pk_id'];
			$company_name = $_POST['company_name'];
			$s_card_color = $_POST['s_card_color'];
			$s_ordernum = $_POST['s_ordernum'];
			$start_date_id = strtotime($_POST['start_date_id']);
			$stop_date_id = $_POST['stop_date_id'];
			if($stop_date_id != ""){ $stop_date_id = strtotime($stop_date_id." 23:59:59"); }

			$sql_select = " SELECT COUNT(*) AS `count` FROM `billing_history` WHERE `status` = 1 ";
			if($company_pk_id != ""){ $sql_select .= " AND `company_pk_id` = ".$company_pk_id." "; }
			if($company_name != ""){ $sql_select .= " AND `company_name` = '".$company_name."' "; }
			if($s_card_color != "all" && $s_card_color != ""){ $sql_select .= " AND `card_color` = '".$s_card_color."' "; }
			if($s_ordernum != ""){ $sql_select .= " AND `ordernum` = '".$s_ordernum."' "; }
			if($start_date_id != ""){ $sql_select .= " AND `update_time` > '".$start_date_id."' "; }
			if($stop_date_id != ""){ $sql_select .= " AND `update_time` < '".$stop_date_id."' "; }
			$data = mysqli_query($conn, $sql_select);
			$row_2 = mysqli_fetch_array($data);

			$sql_sum = " SELECT SUM(`price`) AS `price` FROM `billing_history` WHERE `status` = 1 ";
			if($company_pk_id != ""){ $sql_sum .= " AND `company_pk_id` = ".$company_pk_id." "; }
			if($company_name != ""){ $sql_sum .= " AND `company_name` = '".$company_name."' "; }
			if($s_card_color != "all" && $s_card_color != ""){ $sql_sum .= " AND `card_color` = '".$card_color."' "; }
			if($s_ordernum != ""){ $sql_sum .= " AND `ordernum` = '".$s_ordernum."' "; }
			if($start_date_id != ""){ $sql_sum .= " AND `update_time` > '".$start_date_id."' "; }
			if($stop_date_id != ""){ $sql_sum .= " AND `update_time` < '".$stop_date_id."' "; }
			$res = mysqli_query($conn, $sql_sum);
			$row = mysqli_fetch_array($res);

			if($row_2['count'] == 0){
				$arr = array(
					"code" => 0,
					"message" => "NoData"
				);
			}else{
				$arr = array(
					"code" => 1,
					"price" => ($row['price']==null?0:$row['price']),
					"message" => $row_2['count']
				);
			}
		}else{
			$arr = array(
				"code" => 0,
				"message" => "FAIL"
			);
		}
		$arr = json_encode($arr, JSON_UNESCAPED_UNICODE);
		echo $arr;
	}else if($result == 'a_payment_history'){
		if($conn){
			$company_pk_id = $_POST['company_pk_id'];
			$company_name = $_POST['company_name'];
			$s_card_color = $_POST['s_card_color'];
			$s_ordernum = $_POST['s_ordernum'];
			$start_date_id = strtotime($_POST['start_date_id']);
			$stop_date_id = $_POST['stop_date_id'];
			if($stop_date_id != ""){ $stop_date_id = strtotime($stop_date_id." 23:59:59"); }
			$s_data = $_POST['s_data'];
			$e_data = $_POST['e_data'];

			$sql_select = " SELECT * FROM `billing_history` WHERE `status` = 1 ";
			if($company_pk_id != ""){ $sql_select .= " AND `company_pk_id` = ".$company_pk_id." "; }
			if($company_name != ""){ $sql_select .= " AND `company_name` = '".$company_name."' "; }
			if($s_card_color != "all" && $s_card_color != ""){ $sql_select .= " AND `card_color` = '".$s_card_color."' "; }
			if($s_ordernum != ""){ $sql_select .= " AND `ordernum` = '".$s_ordernum."' "; }
			if($start_date_id != ""){ $sql_select .= " AND `update_time` > '".$start_date_id."' "; }
			if($stop_date_id != ""){ $sql_select .= " AND `update_time` < '".$stop_date_id."' "; }
			$sql_select .= " ORDER BY `update_time` DESC LIMIT ".$s_data.", ".$e_data." ";
			$result = mysqli_query($conn, $sql_select);
			while($row = mysqli_fetch_array($result)){
				$res_list[] = array(
					"pk_id" => $row['pk_id'],
					"company_pk_id" => $row['company_pk_id'],
					"company_name" => $row['company_name'],
					"company_number" => $row['company_number'],
					"itemname" => $row['itemname'],
					"card_color" => $row['card_color'],
					"card_number" => $row['card_number'],
					"price" => $row['price'],
					"ordernum" => $row['ordernum'],
					"update_time" => $row['update_time'],
					"admin_status" => $row['admin_status']
				);
			}
			$res_list = json_encode($res_list, JSON_UNESCAPED_UNICODE);
			if($res_list == "null"){
				$arr = array(
					"code" => 0,
					"message" => "NoData"
				);
			}else{
				$arr = array(
					"code" => 1,
					"message" => $res_list
				);
			}
		}else{
			$arr = array(
				"code" => 0,
				"message" => "FAIL"
			);
		}
		$arr = json_encode($arr, JSON_UNESCAPED_UNICODE);
		echo $arr;
	}else if($result == 'j_set_card'){
		if($conn){
			$j_pk_id = $_POST['j_pk_id'];                  // 주는 회사코드
			$j_company_name = $_POST['j_company_name'];    // 주는 회사이름
			$j_card_version = $_POST['j_card_version'];    // 버전
			$j_card_number = $_POST['j_card_number'];      // 카드장수

			$sql_s_count = " SELECT COUNT(*) AS `count` FROM `card_history` WHERE `card_version` = '".$j_card_version."' AND `status` = 0 ";
			$res_s_count = mysqli_query($conn, $sql_s_count);
			$row_s_count = mysqli_fetch_array($res_s_count);

			if($row_s_count['count'] < $j_card_number){
				$arr = array(
					"code" => 0,
					"message" => "NO"
				);
			}else{
				$time = time();

				if($j_pk_id == 1){
					// 큐브라면 이거 실행
					$timestamp = strtotime("Now");
					$ddate = date("Y-m-d H:i:s", $timestamp);
					$sql_select = " SELECT `pk_id`,`card_number`,`card_color` FROM `card_history` WHERE `card_version` = '".$j_card_version."' AND `status` = 0 ORDER BY `pk_id` ASC LIMIT ".$j_card_number." ";
					$result = mysqli_query($conn, $sql_select);
					$sql_update = " UPDATE `card_history` SET `status` = 1,`update_time` = '".$time."',`company_id` = ".$j_pk_id.",`company_name` = '".$j_company_name."' WHERE `pk_id` IN ( ";
					$sql_insert = " INSERT INTO `card_history` (`pk_id`,`c_pk_id`,`agent_id`,`card_number`,`status`,`insert_time`,`update_time`,`card_color`) VALUES ";

					while($row = mysqli_fetch_array($result)){
						$sql_update .= $row['pk_id'].",";
						$sql_insert .= "(NULL,".$row['pk_id'].",0,'".$row['card_number']."','S','".$ddate."','".$ddate."','".$row['card_color']."'),";
					}
					$sql_update = substr($sql_update, 0, -1);
					$sql_update .= ")";
					$sql_insert = substr($sql_insert, 0, -1);

					mysqli_query($conn, $sql_update);
					mysqli_query($conn_code, $sql_insert);
				}else{
					// 다른 업체면
					if($row_s_count['count'] == $j_card_number){
						$sql_update = " UPDATE `card_history` SET `status` = 1,`update_time` = '".$time."',`company_id` = ".$j_pk_id.",`company_name` = '".$j_company_name."' WHERE `card_version` = '".$j_card_version."' ";
						mysqli_query($conn, $sql_update);
					}else{
						$sql_select = " SELECT `pk_id`,`card_number`,`card_color` FROM `card_history` WHERE `card_version` = '".$j_card_version."' AND `status` = 0 ORDER BY `pk_id` ASC LIMIT ".$j_card_number." ";
						$result = mysqli_query($conn, $sql_select);
						$sql_update = " UPDATE `card_history` SET `status` = 1,`update_time` = '".$time."',`company_id` = ".$j_pk_id.",`company_name` = '".$j_company_name."' WHERE `pk_id` IN ( ";
						while($row = mysqli_fetch_array($result)){
							$sql_update .= $row['pk_id'].",";
						}
						$sql_update = substr($sql_update, 0, -1);
						$sql_update .= ")";
						mysqli_query($conn, $sql_update);
					}
				}

				$arr = array(
					"code" => 1,
					"sql_insert" => $sql_insert,
					"message" => "SUCC"
				);
			}
		}else{
			$arr = array(
				"code" => 0,
				"message" => "FAIL"
			);
		}
		$arr = json_encode($arr, JSON_UNESCAPED_UNICODE);
		echo $arr;
	}else if($result == 'u_login'){
		if($conn){
			$user_id = $_POST['user_id'];
			$password = mysql_new_password($_POST['password']);

			$sql_select = " SELECT `pk_id` FROM `company` WHERE `company_number` = '".$user_id."' AND `password` = '".$password."' ";
			$result = mysqli_query($conn, $sql_select);
			$row = mysqli_fetch_array($result);

			if($row['pk_id']){
				setcookie("uu_mobile",$user_id,0,"/",".livilcard.com");
				setcookie("uu_password",$password,0,"/",".livilcard.com");
				setcookie("uu_code",$row['pk_id'],0,"/",".livilcard.com");
				$arr = array(
					"code" => 1,
					"message" => "SUCC"
				);
			}else{
				$arr = array(
					"code" => 0,
					"message" => "NO"
				);
			}
		}else{
			$arr = array(
				"code" => 0,
				"message" => "FAIL"
			);
		}
		$arr = json_encode($arr, JSON_UNESCAPED_UNICODE);
		echo $arr;
	}else if($result == 'u_ck_cookie'){
		if($conn){
			$sql_select = " SELECT `pk_id`,`company_name`,`company_contact`,`company_number` FROM `company` WHERE `pk_id` = ".$_COOKIE["uu_code"]." AND `company_number` = '".$_COOKIE["uu_mobile"]."' AND `password` = '".$_COOKIE["uu_password"]."' ";
			$result = mysqli_query($conn, $sql_select);
			$row = mysqli_fetch_array($result);
			if($row['pk_id']){
				$arr = array(
					"code" => 1,
					"company_name" => $row['company_name'],
					"company_contact" => $row['company_contact'],
					"company_number" => $row['company_number'],
					"message" => $row['pk_id']
				);
			}else{
				$arr = array(
					"code" => 0,
					"message" => "NO"
				);
			}
		}else{
			$arr = array(
				"code" => 0,
				"message" => "FAIL"
			);
		}
		$arr = json_encode($arr, JSON_UNESCAPED_UNICODE);
		echo $arr;
	}else if($result == 'u_logout'){
		setcookie("uu_mobile",null,-1,"/",".livilcard.com");
		setcookie("uu_password",null,-1,"/",".livilcard.com");
		setcookie("uu_code",null,-1,"/",".livilcard.com");
		$arr = array(
			"code" => 1,
			"message" => "SUCC"
		);
		$arr = json_encode($arr, JSON_UNESCAPED_UNICODE);
		echo $arr;
	}else if($result == 'u_card_history_count'){
		if($conn){
			$pk_id = $_POST['pk_id'];
			$status = $_POST['status'];
			$card_color = $_POST['card_color'];
			$company_version = $_POST['company_version'];
			$card_number = $_POST['card_number'];
			$start_date_u = strtotime($_POST['start_date_u']);
			$stop_date_u = $_POST['stop_date_u'];
			if($stop_date_u != ""){ $stop_date_u = strtotime($stop_date_u." 23:59:59"); }

			$sql_select = " SELECT COUNT(*) AS `count` FROM `card_history` WHERE `company_id` = ".$pk_id." ";
			if($status != "" && $status != 9){ $sql_select .= " AND `status` = ".$status." "; }
			if($card_color != "" && $card_color != "all"){ $sql_select .= " AND `card_color` = '".$card_color."' "; }
			if($company_version != ""){ $sql_select .= " AND `card_version` = '".$company_version."' "; }
			if($card_number != ""){ $sql_select .= " AND `card_number` = '".$card_number."' "; }
			if($start_date_u != ""){ $sql_select .= " AND `update_time` > '".$start_date_u."' "; }
			if($stop_date_u != ""){ $sql_select .= " AND `update_time` < '".$stop_date_u."' "; }
			$data = mysqli_query($conn, $sql_select);
			$row_2 = mysqli_fetch_array($data);
			if($row_2['count'] == 0){
				$arr = array(
					"code" => 0,
					"sql_select" => $sql_select,
					"message" => "NoData"
				);
			}else{
				$arr = array(
					"code" => 1,
					"message" => $row_2['count']
				);
			}
		}else{
			$arr = array(
				"code" => 0,
				"message" => "FAIL"
			);
		}
		$arr = json_encode($arr, JSON_UNESCAPED_UNICODE);
		echo $arr;
	}else if($result == 'u_card_history'){
		if($conn){
			$pk_id = $_POST['pk_id'];
			$status = $_POST['status'];
			$card_color = $_POST['card_color'];
			$company_version = $_POST['company_version'];
			$card_number = $_POST['card_number'];
			$start_date_u = strtotime($_POST['start_date_u']);
			$stop_date_u = $_POST['stop_date_u'];
			if($stop_date_u != ""){ $stop_date_u = strtotime($stop_date_u." 23:59:59"); }
			$s_data = $_POST['s_data'];
			$e_data = $_POST['e_data'];

			$sql_select = " SELECT * FROM `card_history` WHERE `company_id` = ".$pk_id." ";
			if($status != "" && $status != 9){ $sql_select .= " AND `status` = ".$status." "; }
			if($card_color != "" && $card_color != "all"){ $sql_select .= " AND `card_color` = '".$card_color."' "; }
			if($company_version != ""){ $sql_select .= " AND `card_version` = '".$company_version."' "; }
			if($card_number != ""){ $sql_select .= " AND `card_number` = '".$card_number."' "; }
			if($start_date_u != ""){ $sql_select .= " AND `update_time` > '".$start_date_u."' "; }
			if($stop_date_u != ""){ $sql_select .= " AND `update_time` < '".$stop_date_u."' "; }
			$sql_select .= " ORDER BY `pk_id` DESC LIMIT ".$s_data.", ".$e_data." ";
			$result = mysqli_query($conn, $sql_select);
			while($row = mysqli_fetch_array($result)){
				$res_list[] = array(
					"pk_id" => $row['pk_id'],
					"card_number" => $row['card_number'],
					"card_color" => $row['card_color'],
					"card_version" => $row['card_version'],
					"status" => $row['status'],
					"insert_time" => $row['insert_time'],
					"update_time" => $row['update_time'],
					"company_name" => $row['company_name'],
					"issued_time" => $row['issued_time'],
					"remarks" => $row['remarks']
				);
			}
			$res_list = json_encode($res_list, JSON_UNESCAPED_UNICODE);
			if($res_list == "null"){
				$arr = array(
					"code" => 0,
					"message" => "NoData"
				);
			}else{
				$arr = array(
					"code" => 1,
					"message" => $res_list
				);
			}
		}else{
			$arr = array(
				"code" => 0,
				"message" => "FAIL"
			);
		}
		$arr = json_encode($arr, JSON_UNESCAPED_UNICODE);
		echo $arr;
	}else if($result == 'u_placing_order'){
		if($conn){
			$j_pk_id = $_POST['j_pk_id'];
			$remarks_id = $_POST['remarks_id'];
			$time = time();

			$sql_update = " UPDATE `card_history` SET `status` = 3,`issued_time` = '".$time."',`remarks` = '".$remarks_id."' WHERE `pk_id` = ".$j_pk_id." ";
			mysqli_query($conn, $sql_update);

			$arr = array(
				"code" => 1,
				"message" => "SUCC"
			);
		}else{
			$arr = array(
				"code" => 0,
				"message" => "FAIL"
			);
		}
		$arr = json_encode($arr, JSON_UNESCAPED_UNICODE);
		echo $arr;
	}else if($result == 'card_unit_price'){
		if($conn){
			$pk_id = $_POST['pk_id'];
			$sql_select = " SELECT `card_unit_price` FROM `company` WHERE `pk_id` = ".$pk_id." ";
			$result = mysqli_query($conn, $sql_select);
			$row = mysqli_fetch_array($result);
			$arr = array(
				"code" => 1,
				"message" => $row['card_unit_price']
			);
		}else{
			$arr = array(
				"code" => 0,
				"message" => "FAIL"
			);
		}
		$arr = json_encode($arr, JSON_UNESCAPED_UNICODE);
		echo $arr;
	}else if($result == 'u_payment_history_count'){
		if($conn){
			$pk_id = $_POST['pk_id'];
			$s_status = $_POST['s_status'];
			$s_card_color = $_POST['s_card_color'];
			$s_ordernum = $_POST['s_ordernum'];
			$s_start_date = strtotime($_POST['s_start_date']);
			$s_stop_date = $_POST['s_stop_date'];
			if($s_stop_date != ""){ $s_stop_date = strtotime($s_stop_date." 23:59:59"); }

			$sql_select = " SELECT COUNT(*) AS `count` FROM `billing_history` WHERE `company_pk_id` = ".$pk_id." ";
			if($s_status != 9 && $s_status != ""){ $sql_select .= " AND `status` = ".$s_status." "; }
			if($s_card_color != "all" && $s_card_color != ""){ $sql_select .= " AND `card_color` = '".$s_card_color."' "; }
			if($s_ordernum != ""){ $sql_select .= " AND `ordernum` = '".$s_ordernum."' "; }
			if($s_start_date != ""){ $sql_select .= " AND `update_time` > '".$s_start_date."' "; }
			if($s_stop_date != ""){ $sql_select .= " AND `update_time` < '".$s_stop_date."' "; }
			$data = mysqli_query($conn, $sql_select);
			$row_2 = mysqli_fetch_array($data);

			$sql_sum = " SELECT SUM(`price`) AS `price` FROM `billing_history` WHERE `company_pk_id` = ".$pk_id." ";
			if($s_status != 9 && $s_status != ""){ $sql_sum .= " AND `status` = ".$s_status." "; }
			if($s_card_color != "all" && $s_card_color != ""){ $sql_sum .= " AND `card_color` = '".$s_card_color."' "; }
			if($s_ordernum != ""){ $sql_sum .= " AND `ordernum` = '".$s_ordernum."' "; }
			if($s_start_date != ""){ $sql_sum .= " AND `update_time` > '".$s_start_date."' "; }
			if($s_stop_date != ""){ $sql_sum .= " AND `update_time` < '".$s_stop_date."' "; }
			$res = mysqli_query($conn, $sql_sum);
			$row = mysqli_fetch_array($res);

			if($row_2['count'] == 0){
				$arr = array(
					"code" => 0,
					"message" => "NoData"
				);
			}else{
				$arr = array(
					"code" => 1,
					"sum_price" => $row['price'],
					"message" => $row_2['count']
				);
			}
		}else{
			$arr = array(
				"code" => 0,
				"message" => "FAIL"
			);
		}
		$arr = json_encode($arr, JSON_UNESCAPED_UNICODE);
		echo $arr;
	}else if($result == 'u_payment_history'){
		if($conn){
			$pk_id = $_POST['pk_id'];
			$s_status = $_POST['s_status'];
			$s_card_color = $_POST['s_card_color'];
			$s_ordernum = $_POST['s_ordernum'];
			$s_start_date = strtotime($_POST['s_start_date']);
			$s_stop_date = $_POST['s_stop_date'];
			if($s_stop_date != ""){ $s_stop_date = strtotime($s_stop_date." 23:59:59"); }
			$s_data = $_POST['s_data'];
			$e_data = $_POST['e_data'];

			$sql_select = " SELECT * FROM `billing_history` WHERE `company_pk_id` = ".$pk_id." ";
			if($s_status != 9 && $s_status != ""){ $sql_select .= " AND `status` = ".$s_status." "; }
			if($s_card_color != "all" && $s_card_color != ""){ $sql_select .= " AND `card_color` = '".$s_card_color."' "; }
			if($s_ordernum != ""){ $sql_select .= " AND `ordernum` = '".$s_ordernum."' "; }
			if($s_start_date != ""){ $sql_select .= " AND `update_time` > '".$s_start_date."' "; }
			if($s_stop_date != ""){ $sql_select .= " AND `update_time` < '".$s_stop_date."' "; }
			$sql_select .= " ORDER BY `pk_id` DESC LIMIT ".$s_data.", ".$e_data." ";
			$result = mysqli_query($conn, $sql_select);
			while($row = mysqli_fetch_array($result)){
				$res_list[] = array(
					"pk_id" => $row['pk_id'],
					"itemname" => $row['itemname'],
					"card_color" => $row['card_color'],
					"card_number" => $row['card_number'],
					"price" => $row['price'],
					"status" => $row['status'],
					"ordernum" => $row['ordernum'],
					"update_time" => $row['update_time']
				);
			}
			$res_list = json_encode($res_list, JSON_UNESCAPED_UNICODE);
			if($res_list == "null"){
				$arr = array(
					"code" => 0,
					"message" => "NoData"
				);
			}else{
				$arr = array(
					"code" => 1,
					"message" => $res_list
				);
			}
		}else{
			$arr = array(
				"code" => 0,
				"message" => "FAIL"
			);
		}
		$arr = json_encode($arr, JSON_UNESCAPED_UNICODE);
		echo $arr;
	}else if($result == 'a_f_issued'){
		if($conn){
			$j_pk_id = $_POST['j_pk_id'];
			$sql_update = " UPDATE `billing_history` SET `admin_status` = 1 WHERE `pk_id` = ".$j_pk_id." ";
			mysqli_query($conn, $sql_update);

			$arr = array(
				"code" => 1,
				"message" => "SUCC"
			);
		}else{
			$arr = array(
				"code" => 0,
				"message" => "FAIL"
			);
		}
		$arr = json_encode($arr, JSON_UNESCAPED_UNICODE);
		echo $arr;
	}else if($result == 'a_order_pay'){
		if($conn){
			$j_pk_id = $_POST['j_pk_id'];

			$sql_select = " SELECT `order_value` FROM `billing_history` WHERE `pk_id` = ".$j_pk_id." AND `status` = 0 ";
			$result = mysqli_query($conn, $sql_select);
			$row = mysqli_fetch_array($result);

			if($row['order_value']){
				$arr = array(
					"code" => 1,
					"message" => $row['order_value']
				);
			}else{
				$arr = array(
					"code" => 0,
					"message" => "NoData"
				);
			}
		}else{
			$arr = array(
				"code" => 0,
				"message" => "FAIL"
			);
		}
		$arr = json_encode($arr, JSON_UNESCAPED_UNICODE);
		echo $arr;
	}else if($result == 'u_add_franchisee'){
		if($conn){
			$pk_id = $_POST['pk_id'];
			$company_name = $_POST['company_name'];
			$company_contact = $_POST['company_contact'];
			$company_number = $_POST['company_number'];
			$i_app_uid = $_POST['i_app_uid'];
			$i_app_user_name = $_POST['i_app_user_name'];

			$sql_select = " SELECT `pk_id` FROM `franchisee_history` WHERE `app_uid` = ".$i_app_uid." ";
			$result = mysqli_query($conn, $sql_select);
			$row = mysqli_fetch_array($result);

			if($row['pk_id']){
				$arr = array(
					"code" => 0,
					"message" => "YOU"
				);
			}else{
				$row_p = post($http_url, array('result'=>'u_add_franchisee','i_app_uid'=>$i_app_uid,'i_app_user_name'=>$i_app_user_name));
				$row_p = json_decode($row_p, JSON_UNESCAPED_UNICODE);
				$time = time();

				if($row_p['code'] == 1){
					$sql_insert = " INSERT INTO `franchisee_history` (`pk_id`,`app_uid`,`app_name`,`app_introduce`,`company_pk_id`,`company_name`,`company_contact`,`company_number`,`status`,`insert_time`,`update_time`,`lement_time`,`status_memo`) VALUES ";
					$sql_insert .= " (NULL,".$row_p['id'].",'".$row_p['name']."','".$row_p['introduce']."',".$pk_id.",'".$company_name."','".$company_contact."','".$company_number."',0,'".$time."','".$time."','".$time."',' ') ";
					mysqli_query($conn, $sql_insert);

					$arr = array(
						"code" => 1,
						"message" => "SUCC"
					);
				}else{
					if($row_p['FAIL']){
						$arr = array(
							"code" => 0,
							"message" => "FAIL"
						);
					}else{
						$arr = array(
							"code" => 0,
							"message" => "NoData"
						);
					}
				}
			}
		}else{
			$arr = array(
				"code" => 0,
				"message" => "FAIL"
			);
		}
		$arr = json_encode($arr, JSON_UNESCAPED_UNICODE);
		echo $arr;
	}else if($result == 'u_franchisee_count'){
		if($conn){
			$pk_id = $_POST['pk_id'];
			$s_status = $_POST['s_status'];
			$s_app_uid = $_POST['s_app_uid'];
			$s_app_name = $_POST['s_app_name'];
			$s_start_date = strtotime($_POST['s_start_date']);
			$s_stop_date = $_POST['s_stop_date'];
			if($s_stop_date != ""){ $s_stop_date = strtotime($s_stop_date." 23:59:59"); }

			$sql_select = " SELECT COUNT(*) AS `count` FROM `store_history` WHERE `t_status` = ".$pk_id." ";
			if($s_status != 9 && $s_status != ""){ $sql_select .= " AND `status` = ".$s_status." "; }
			if($s_app_uid != ""){ $sql_select .= " AND `store_id` = ".$s_app_uid." "; }
			if($s_app_name != ""){ $sql_select .= " AND `store_name` = '".$s_app_name."' "; }
			if($s_start_date != ""){ $sql_select .= " AND `update_time` > '".$s_start_date."' "; }
			if($s_stop_date != ""){ $sql_select .= " AND `update_time` < '".$s_stop_date."' "; }
			$data = mysqli_query($conn, $sql_select);
			$row_2 = mysqli_fetch_array($data);

			if($row_2['count'] == 0){
				$arr = array(
					"code" => 0,
					"message" => "NoData"
				);
			}else{
				$arr = array(
					"code" => 1,
					"message" => $row_2['count']
				);
			}
		}else{
			$arr = array(
				"code" => 0,
				"message" => "FAIL"
			);
		}
		$arr = json_encode($arr, JSON_UNESCAPED_UNICODE);
		echo $arr;
	}else if($result == 'u_franchisee'){
		if($conn){
			$pk_id = $_POST['pk_id'];
			$s_status = $_POST['s_status'];
			$s_app_uid = $_POST['s_app_uid'];
			$s_app_name = $_POST['s_app_name'];
			$s_start_date = strtotime($_POST['s_start_date']);
			$s_stop_date = $_POST['s_stop_date'];
			if($s_stop_date != ""){ $s_stop_date = strtotime($s_stop_date." 23:59:59"); }
			$s_data = $_POST['s_data'];
			$e_data = $_POST['e_data'];

			$sql_select = " SELECT * FROM `store_history` WHERE `t_status` = ".$pk_id." ";
			if($s_status != 9 && $s_status != ""){ $sql_select .= " AND `status` = ".$s_status." "; }
			if($s_app_uid != ""){ $sql_select .= " AND `store_id` = ".$s_app_uid." "; }
			if($s_app_name != ""){ $sql_select .= " AND `store_name` = '".$s_app_name."' "; }
			if($s_start_date != ""){ $sql_select .= " AND `update_time` > '".$s_start_date."' "; }
			if($s_stop_date != ""){ $sql_select .= " AND `update_time` < '".$s_stop_date."' "; }
			$sql_select .= " ORDER BY `pk_id` DESC LIMIT ".$s_data.", ".$e_data." ";
			$result = mysqli_query($conn, $sql_select);
			while($row = mysqli_fetch_array($result)){
				$res_list[] = array(
					"pk_id" => $row['pk_id'],
					"agent_id" => $row['agent_id'],
					"store_id" => $row['store_id'],
					"store_name" => $row['store_name'],
					"store_account" => $row['store_account'],
					"status" => $row['status'],
					"t_status" => $row['t_status'],
					"total_fee" => $row['total_fee'],
					"insert_time" => $row['insert_time'],
					"update_time" => $row['update_time']
				);
			}
			$res_list = json_encode($res_list, JSON_UNESCAPED_UNICODE);
			if($res_list == "null"){
				$arr = array(
					"code" => 0,
					"message" => "NoData"
				);
			}else{
				$arr = array(
					"code" => 1,
					"message" => $res_list
				);
			}
		}else{
			$arr = array(
				"code" => 0,
				"message" => "FAIL"
			);
		}
		$arr = json_encode($arr, JSON_UNESCAPED_UNICODE);
		echo $arr;
	}else if($result == 'a_franchisee_count'){
		if($conn){
			$s_status = $_POST['s_status'];
			$s_company_pk_id = $_POST['s_company_pk_id'];
			$s_app_uid = $_POST['s_app_uid'];
			$s_app_name = $_POST['s_app_name'];
			$s_start_date = strtotime($_POST['s_start_date']);
			$s_stop_date = $_POST['s_stop_date'];
			if($s_stop_date != ""){ $s_stop_date = strtotime($s_stop_date." 23:59:59"); }

			$sql_select = " SELECT COUNT(*) AS `count` FROM `store_history` WHERE `pk_id` != '' ";
			if($s_status != 9 && $s_status != ""){ $sql_select .= " AND `status` = ".$s_status." "; }
			if($s_company_pk_id != ""){ $sql_select .= " AND `t_status` = ".$s_company_pk_id." "; }
			if($s_app_uid != ""){ $sql_select .= " AND `store_id` = ".$s_app_uid." "; }
			if($s_app_name != ""){ $sql_select .= " AND `store_name` = '".$s_app_name."' "; }
			if($s_start_date != ""){ $sql_select .= " AND `update_time` > '".$s_start_date."' "; }
			if($s_stop_date != ""){ $sql_select .= " AND `update_time` < '".$s_stop_date."' "; }
			$data = mysqli_query($conn, $sql_select);
			$row_2 = mysqli_fetch_array($data);

			if($row_2['count'] == 0){
				$arr = array(
					"code" => 0,
					"message" => "NoData"
				);
			}else{
				$arr = array(
					"code" => 1,
					"message" => $row_2['count']
				);
			}
		}else{
			$arr = array(
				"code" => 0,
				"message" => "FAIL"
			);
		}
		$arr = json_encode($arr, JSON_UNESCAPED_UNICODE);
		echo $arr;
	}else if($result == 'a_franchisee'){
		if($conn){
			$s_status = $_POST['s_status'];
			$s_company_pk_id = $_POST['s_company_pk_id'];
			$s_app_uid = $_POST['s_app_uid'];
			$s_app_name = $_POST['s_app_name'];
			$s_start_date = strtotime($_POST['s_start_date']);
			$s_stop_date = $_POST['s_stop_date'];
			if($s_stop_date != ""){ $s_stop_date = strtotime($s_stop_date." 23:59:59"); }
			$s_data = $_POST['s_data'];
			$e_data = $_POST['e_data'];

			$sql_select = " SELECT * FROM `store_history` WHERE `pk_id` != '' ";
			if($s_status != 9 && $s_status != ""){ $sql_select .= " AND `status` = ".$s_status." "; }
			if($s_company_pk_id != ""){ $sql_select .= " AND `t_status` = ".$s_company_pk_id." "; }
			if($s_app_uid != ""){ $sql_select .= " AND `store_id` = ".$s_app_uid." "; }
			if($s_app_name != ""){ $sql_select .= " AND `store_name` = '".$s_app_name."' "; }
			if($s_start_date != ""){ $sql_select .= " AND `update_time` > '".$s_start_date."' "; }
			if($s_stop_date != ""){ $sql_select .= " AND `update_time` < '".$s_stop_date."' "; }
			$sql_select .= " ORDER BY `pk_id` DESC LIMIT ".$s_data.", ".$e_data." ";
			$result = mysqli_query($conn, $sql_select);
			while($row = mysqli_fetch_array($result)){
				$sql_s = " SELECT `company_name`,`company_contact` FROM `company` WHERE `pk_id` = ".$row['t_status']." ";
				$res_s = mysqli_query($conn, $sql_s);
				$row_s = mysqli_fetch_array($res_s);

				$res_list[] = array(
					"pk_id" => $row['pk_id'],
					"agent_id" => $row['agent_id'],
					"store_id" => $row['store_id'],
					"store_name" => $row['store_name'],
					"store_account" => $row['store_account'],
					"status" => $row['status'],
					"t_status" => $row['t_status'],
					"total_fee" => $row['total_fee'],
					"insert_time" => $row['insert_time'],
					"update_time" => $row['update_time'],
					"company_name" => $row_s['company_name'],
					"company_contact" => $row_s['company_contact']
				);
			}
			$res_list = json_encode($res_list, JSON_UNESCAPED_UNICODE);
			if($res_list == "null"){
				$arr = array(
					"code" => 0,
					"message" => "NoData"
				);
			}else{
				$arr = array(
					"code" => 1,
					"message" => $res_list
				);
			}
		}else{
			$arr = array(
				"code" => 0,
				"message" => "FAIL"
			);
		}
		$arr = json_encode($arr, JSON_UNESCAPED_UNICODE);
		echo $arr;
	}else if($result == 'a_judge_fail'){
		if($conn){
			$j_pk_id = $_POST['j_pk_id'];
			$time = time();

			$sql_update = " UPDATE `store_history` SET `status` = 1, `update_time` = '".$time."' WHERE `pk_id` = ".$j_pk_id." ";
			mysqli_query($conn, $sql_update);

			$arr = array(
				"code" => 1,
				"message" => "SUCC"
			);
		}else{
			$arr = array(
				"code" => 0,
				"message" => "FAIL"
			);
		}
		$arr = json_encode($arr, JSON_UNESCAPED_UNICODE);
		echo $arr;
	}else if($result == 'a_judge_succ'){
		if($conn){
			$j_pk_id = $_POST['j_pk_id'];
			$time = time();

			$sql_update = " UPDATE `store_history` SET `status` = 2, `update_time` = '".$time."' WHERE `pk_id` = ".$j_pk_id." ";
			mysqli_query($conn, $sql_update);

			$arr = array(
				"code" => 1,
				"message" => "SUCC"
			);
		}else{
			$arr = array(
				"code" => 0,
				"message" => "FAIL"
			);
		}
		$arr = json_encode($arr, JSON_UNESCAPED_UNICODE);
		echo $arr;
	}else if($result == 'a_modif_card_price'){
		if($conn){
			$z_card_unit_price = $_POST['z_card_unit_price'];
			$z_card_visa_1 = $_POST['z_card_visa_1'];
			$z_card_visa_2 = $_POST['z_card_visa_2'];
			$z_terminal_price = $_POST['z_terminal_price'];
			$j_pk_id = $_POST['j_pk_id'];
			$sql_update = " UPDATE `company` SET `card_unit_price` = ".$z_card_unit_price.", `card_visa_1` = ".$z_card_visa_1.", `card_visa_2` = ".$z_card_visa_2.", `terminal_price` = ".$z_terminal_price." WHERE `pk_id` = ".$j_pk_id." ";
			mysqli_query($conn, $sql_update);

			$arr = array(
				"code" => 1,
				"message" => "SUCC"
			);
		}else{
			$arr = array(
				"code" => 0,
				"message" => "FAIL"
			);
		}
		$arr = json_encode($arr, JSON_UNESCAPED_UNICODE);
		echo $arr;
	}else if($result == 'u_reexamination'){
		if($conn){
			$j_pk_id = $_POST['j_pk_id'];
			$sql_update = " UPDATE `franchisee_history` SET `status` = 0, `status_memo` = '' WHERE `pk_id` = ".$j_pk_id." ";
			mysqli_query($conn, $sql_update);

			$arr = array(
				"code" => 1,
				"message" => "SUCC"
			);
		}else{
			$arr = array(
				"code" => 0,
				"message" => "FAIL"
			);
		}
		$arr = json_encode($arr, JSON_UNESCAPED_UNICODE);
		echo $arr;
	}else if($result == 'a_card_password'){
		if($conn){
			$sql_select = " SELECT `pk_id`,`card_number`,`password` FROM `card_history` ";
			$result = mysqli_query($conn, $sql_select);
			while($row = mysqli_fetch_array($result)){
				$number = strToHex($row['card_number'].$row['password']);
				$number = $number."000000000000000000000000000000000000000000000000000000";
				$sql_update = " UPDATE `card_history` SET `card_password_16` = '".$number."' WHERE `pk_id` = ".$row['pk_id']." ";
				// $aaaaaa = "B-".$row['card_number'];
				// $sql_update = " UPDATE `card_history` SET `card_number` = '".$aaaaaa."' WHERE `pk_id` = ".$row['pk_id']." ";
				mysqli_query($conn, $sql_update);
			}
			$arr = array(
				"code" => 1,
				"message" => "SUCC"
			);
		}else{
			$arr = array(
				"code" => 0,
				"message" => "FAIL"
			);
		}
		$arr = json_encode($arr, JSON_UNESCAPED_UNICODE);
		echo $arr;
	}else if($result == 'card_visa_price'){
		if($conn){
			$pk_id = $_POST['pk_id'];
			$sql_select = " SELECT `card_visa_1`,`card_visa_2` FROM `company` WHERE `pk_id` = ".$pk_id." ";
			$result = mysqli_query($conn, $sql_select);
			$row = mysqli_fetch_array($result);
			$arr = array(
				"code" => 1,
				"card_visa_1" => $row['card_visa_1'],
				"card_visa_2" => $row['card_visa_2']
			);
		}else{
			$arr = array(
				"code" => 0,
				"message" => "FAIL"
			);
		}
		$arr = json_encode($arr, JSON_UNESCAPED_UNICODE);
		echo $arr;
	}else if($result == 'select_comm'){
		if($conn){
			$sql_select = " SELECT `pk_id`,`company_name` FROM `company` ";
			$result = mysqli_query($conn, $sql_select);
			while($row = mysqli_fetch_array($result)){
				$res_list[] = array(
					"pk_id" => $row['pk_id'],
					"company_name" => $row['company_name'],
				);
			}
			$res_list = json_encode($res_list, JSON_UNESCAPED_UNICODE);
			if($res_list == "null"){
				$arr = array(
					"code" => 0,
					"message" => "NoData"
				);
			}else{
				$arr = array(
					"code" => 1,
					"message" => $res_list
				);
			}
		}else{
			$arr = array(
				"code" => 0,
				"message" => "FAIL"
			);
		}
		$arr = json_encode($arr, JSON_UNESCAPED_UNICODE);
		echo $arr;
	}else if($result == 'a_add_vasacard'){
		if($conn){
			$i_status = $_POST['i_status'];
			$i_card_color = $_POST['i_card_color'];
			$i_card_num = $_POST['i_card_num'];
			$i_card_password = $_POST['i_card_password'];
			$i_company_name = $_POST['i_company_name'];
			$i_end_date1 = $_POST['i_end_date1'];
			$i_end_date2 = $_POST['i_end_date2'];
			$time = time();

			$sql_select = " SELECT `pk_id` FROM `vasa_card_history` WHERE `card_number` = '".$i_card_num."' ";
			$result = mysqli_query($conn, $sql_select);
			$row = mysqli_fetch_array($result);

			if($row['pk_id']){
				$arr = array(
					"code" => 0,
					"message" => "YOU"
				);
			}else{
				$sql_insert = " INSERT INTO `vasa_card_history` (`pk_id`,`card_number`,`password`,`card_color`,`end_date1`,`end_date2`,`company_id`,`company_name`,`insert_time`) VALUES ";
				$sql_insert .= "(NULL,'".$i_card_num."','".$i_card_password."','".$i_card_color."','".$i_end_date1."','".$i_end_date2."',".$i_status.",'".$i_company_name."','".$time."')";
				mysqli_query($conn, $sql_insert);

				$arr = array(
					"code" => 1,
					"message" => "SUCC"
				);
			}
		}else{
			$arr = array(
				"code" => 0,
				"message" => "FAIL"
			);
		}
		$arr = json_encode($arr, JSON_UNESCAPED_UNICODE);
		echo $arr;
	}else if($result == 'a_visacard_history_count'){
		if($conn){
			$card_color = $_POST['card_color'];
			$card_number = $_POST['card_number'];
			$company_name = $_POST['company_name'];
			$start_date_id = strtotime($_POST['start_date_id']);
			$stop_date_id = $_POST['stop_date_id'];
			if($stop_date_id != ""){ $stop_date_id = strtotime($stop_date_id." 23:59:59"); }

			$sql_select = " SELECT COUNT(*) AS `count` FROM `vasa_card_history` WHERE `pk_id` != '' ";
			if($status != 9 && $status != ""){ $sql_select .= " AND `status` = ".$status." "; }
			if($card_color != "all" && $card_color != ""){ $sql_select .= " AND `card_color` = '".$card_color."' "; }
			if($card_number != ""){ $sql_select .= " AND `card_number` = '".$card_number."' "; }
			if($company_name != ""){ $sql_select .= " AND `company_name` = '".$company_name."' "; }
			if($start_date_id != ""){ $sql_select .= " AND `insert_time` > '".$start_date_id."' "; }
			if($stop_date_id != ""){ $sql_select .= " AND `insert_time` < '".$stop_date_id."' "; }
			$data = mysqli_query($conn, $sql_select);
			$row_2 = mysqli_fetch_array($data);
			if($row_2['count'] == 0){
				$arr = array(
					"code" => 0,
					"sql_select" => $sql_select,
					"message" => "NoData"
				);
			}else{
				$arr = array(
					"code" => 1,
					"message" => $row_2['count']
				);
			}
		}else{
			$arr = array(
				"code" => 0,
				"message" => "FAIL"
			);
		}
		$arr = json_encode($arr, JSON_UNESCAPED_UNICODE);
		echo $arr;
	}else if($result == 'a_visacard_history'){
		if($conn){
			$card_color = $_POST['card_color'];
			$card_number = $_POST['card_number'];
			$company_name = $_POST['company_name'];
			$start_date_id = strtotime($_POST['start_date_id']);
			$stop_date_id = $_POST['stop_date_id'];
			if($stop_date_id != ""){ $stop_date_id = strtotime($stop_date_id." 23:59:59"); }
			$s_data = $_POST['s_data'];
			$e_data = $_POST['e_data'];

			$sql_select = " SELECT * FROM `vasa_card_history` WHERE `pk_id` != '' ";
			if($status != 9 && $status != ""){ $sql_select .= " AND `status` = ".$status." "; }
			if($card_color != "all" && $card_color != ""){ $sql_select .= " AND `card_color` = '".$card_color."' "; }
			if($card_number != ""){ $sql_select .= " AND `card_number` = '".$card_number."' "; }
			if($company_name != ""){ $sql_select .= " AND `company_name` = '".$company_name."' "; }
			if($start_date_id != ""){ $sql_select .= " AND `insert_time` > '".$start_date_id."' "; }
			if($stop_date_id != ""){ $sql_select .= " AND `insert_time` < '".$stop_date_id."' "; }
			$sql_select .= " ORDER BY `pk_id` DESC LIMIT ".$s_data.", ".$e_data." ";
			$result = mysqli_query($conn, $sql_select);
			while($row = mysqli_fetch_array($result)){
				$res_list[] = array(
					"pk_id" => $row['pk_id'],
					"card_number" => $row['card_number'],
					"password" => $row['password'],
					"card_color" => $row['card_color'],
					"end_date1" => $row['end_date1'],
					"end_date2" => $row['end_date2'],
					"insert_time" => $row['insert_time'],
					"company_id" => $row['company_id'],
					"company_name" => $row['company_name']
				);
			}
			$res_list = json_encode($res_list, JSON_UNESCAPED_UNICODE);
			if($res_list == "null"){
				$arr = array(
					"code" => 0,
					"message" => "NoData"
				);
			}else{
				$arr = array(
					"code" => 1,
					"message" => $res_list
				);
			}
		}else{
			$arr = array(
				"code" => 0,
				"message" => "FAIL"
			);
		}
		$arr = json_encode($arr, JSON_UNESCAPED_UNICODE);
		echo $arr;
	}else if($result == 'a_visacard_delete'){
		if($conn){
			$j_pk_id = $_POST['j_pk_id'];

			$sql_delete = " DELETE FROM `vasa_card_history` WHERE `pk_id` = ".$j_pk_id." ";
			mysqli_query($conn, $sql_delete);

			$arr = array(
				"code" => 1,
				"message" => "SUCC"
			);
		}else{
			$arr = array(
				"code" => 0,
				"message" => "FAIL"
			);
		}
		$arr = json_encode($arr, JSON_UNESCAPED_UNICODE);
		echo $arr;
	}else if($result == 'a_modif_vasacard'){
		if($conn){
			$m_card_num = $_POST['m_card_num'];
			$m_card_password = $_POST['m_card_password'];
			$j_pk_id = $_POST['j_pk_id'];

			$sql_update = " UPDATE `vasa_card_history` SET `card_number` = '".$m_card_num."', `password` = '".$m_card_password."' WHERE `pk_id` = ".$j_pk_id." ";
			mysqli_query($conn, $sql_update);
			$arr = array(
				"code" => 1,
				"message" => "SUCC"
			);
/*
			$sql_select = " SELECT `pk_id` FROM `vasa_card_history` WHERE `card_number` = '".$m_card_num."' ";
			$result = mysqli_query($conn, $sql_select);
			$row = mysqli_fetch_array($result);

			if($row['pk_id']){
				$arr = array(
					"code" => 0,
					"message" => "NO"
				);
			}else{
				$sql_update = " UPDATE `vasa_card_history` SET `card_number` = '".$m_card_num."', `password` = '".$m_card_password."' WHERE `pk_id` = ".$j_pk_id." ";
				mysqli_query($conn, $sql_update);
				$arr = array(
					"code" => 1,
					"message" => "SUCC"
				);
			}
			*/
		}else{
			$arr = array(
				"code" => 0,
				"message" => "FAIL"
			);
		}
		$arr = json_encode($arr, JSON_UNESCAPED_UNICODE);
		echo $arr;
	}else if($result == 'u_visacard_history_count'){
		if($conn){
			$pk_id = $_POST['pk_id'];
			$s_status = $_POST['s_status'];
			$s_card_color = $_POST['s_card_color'];
			$s_card_number = $_POST['s_card_number'];
			$s_start_date = strtotime($_POST['s_start_date']);
			$s_stop_date = $_POST['s_stop_date'];
			if($s_stop_date != ""){ $s_stop_date = strtotime($s_stop_date." 23:59:59"); }

			$sql_select = " SELECT COUNT(*) AS `count` FROM `vasa_card_history` WHERE `company_id` = ".$pk_id." ";
			if($s_status != "" && $s_status != 9){ $sql_select .= " AND `status` = ".$s_status." "; }
			if($s_card_color != "" && $s_card_color != "all"){ $sql_select .= " AND `card_color` = '".$s_card_color."' "; }
			if($s_card_number != ""){ $sql_select .= " AND `card_number` = '".$s_card_number."' "; }
			if($s_start_date != ""){ $sql_select .= " AND `insert_time` > '".$s_start_date."' "; }
			if($s_stop_date != ""){ $sql_select .= " AND `insert_time` < '".$s_stop_date."' "; }
			$data = mysqli_query($conn, $sql_select);
			$row_2 = mysqli_fetch_array($data);
			if($row_2['count'] == 0){
				$arr = array(
					"code" => 0,
					"message" => "NoData"
				);
			}else{
				$arr = array(
					"code" => 1,
					"message" => $row_2['count']
				);
			}
		}else{
			$arr = array(
				"code" => 0,
				"message" => "FAIL"
			);
		}
		$arr = json_encode($arr, JSON_UNESCAPED_UNICODE);
		echo $arr;
	}else if($result == 'u_visacard_history'){
		if($conn){
			$pk_id = $_POST['pk_id'];
			$s_status = $_POST['s_status'];
			$s_card_color = $_POST['s_card_color'];
			$s_card_number = $_POST['s_card_number'];
			$s_start_date = strtotime($_POST['s_start_date']);
			$s_stop_date = $_POST['s_stop_date'];
			if($s_stop_date != ""){ $s_stop_date = strtotime($s_stop_date." 23:59:59"); }
			$s_data = $_POST['s_data'];
			$e_data = $_POST['e_data'];

			$sql_select = " SELECT * FROM `vasa_card_history` WHERE `company_id` = ".$pk_id." ";
			if($s_status != "" && $s_status != 9){ $sql_select .= " AND `status` = ".$s_status." "; }
			if($s_card_color != "" && $s_card_color != "all"){ $sql_select .= " AND `card_color` = '".$s_card_color."' "; }
			if($s_card_number != ""){ $sql_select .= " AND `card_number` = '".$s_card_number."' "; }
			if($s_start_date != ""){ $sql_select .= " AND `insert_time` > '".$s_start_date."' "; }
			if($s_stop_date != ""){ $sql_select .= " AND `insert_time` < '".$s_stop_date."' "; }
			$sql_select .= " ORDER BY `pk_id` DESC LIMIT ".$s_data.", ".$e_data." ";
			$result = mysqli_query($conn, $sql_select);
			while($row = mysqli_fetch_array($result)){
				$res_list[] = array(
					"pk_id" => $row['pk_id'],
					"card_number" => $row['card_number'],
					"card_color" => $row['card_color'],
					"end_date1" => $row['end_date1'],
					"end_date2" => $row['end_date2'],
					"company_id" => $row['company_id'],
					"company_name" => $row['company_name'],
					"insert_time" => $row['insert_time'],
					"remarks" => $row['remarks'],
					"status" => $row['status']
				);
			}
			$res_list = json_encode($res_list, JSON_UNESCAPED_UNICODE);
			if($res_list == "null"){
				$arr = array(
					"code" => 0,
					"message" => "NoData"
				);
			}else{
				$arr = array(
					"code" => 1,
					"message" => $res_list
				);
			}
		}else{
			$arr = array(
				"code" => 0,
				"message" => "FAIL"
			);
		}
		$arr = json_encode($arr, JSON_UNESCAPED_UNICODE);
		echo $arr;
	}else if($result == 'u_order_action'){
		if($conn){
			$j_pk_id = $_POST['j_pk_id'];
			$remarks_id = $_POST['remarks_id'];


			$sql_update = " UPDATE `vasa_card_history` SET `remarks` = '".$remarks_id."', `status` = 1 WHERE `pk_id` = ".$j_pk_id." ";
			mysqli_query($conn, $sql_update);

			$arr = array(
				"code" => 1,
				"message" => "SUCC"
			);
		}else{
			$arr = array(
				"code" => 0,
				"message" => "FAIL"
			);
		}
		$arr = json_encode($arr, JSON_UNESCAPED_UNICODE);
		echo $arr;
	}else if($result == 'u_information'){
		if($conn){
			$pk_id = $_POST['pk_id'];
			$m_company_name = $_POST['m_company_name'];
			$m_company_contact = $_POST['m_company_contact'];
			$m_company_number = $_POST['m_company_number'];

			$sql_update = " UPDATE `company` SET `company_name` = '".$m_company_name."', `company_contact` = '".$m_company_contact."', `company_number` = '".$m_company_number."' WHERE `pk_id` = ".$pk_id." ";
			mysqli_query($conn, $sql_update);

			$arr = array(
				"code" => 1,
				"message" => "SUCC"
			);
		}else{
			$arr = array(
				"code" => 0,
				"message" => "FAIL"
			);
		}
		$arr = json_encode($arr, JSON_UNESCAPED_UNICODE);
		echo $arr;
	}else if($result == 'u_password'){
		if($conn){
			$pk_id = $_POST['pk_id'];
			$m_o_password = mysql_new_password($_POST['m_o_password']);
			$m_n_password = mysql_new_password($_POST['m_n_password']);

			$sql_select = " SELECT `pk_id` FROM `company` WHERE `pk_id` = ".$pk_id." AND `password` = '".$m_o_password."' ";
			$result = mysqli_query($conn, $sql_select);
			$row = mysqli_fetch_array($result);

			if($row['pk_id']){
				$sql_update = " UPDATE `company` SET `password` = '".$m_n_password."' WHERE `pk_id` = ".$pk_id." ";
				mysqli_query($conn, $sql_update);

				$arr = array(
					"code" => 1,
					"message" => "SUCC"
				);
			}else{
				$arr = array(
					"code" => 0,
					"message" => "NO"
				);
			}
		}else{
			$arr = array(
				"code" => 0,
				"message" => "FAIL"
			);
		}
		$arr = json_encode($arr, JSON_UNESCAPED_UNICODE);
		echo $arr;
	}else if($result == 'terminal_price'){
		if($conn){
			$pk_id = $_POST['pk_id'];
			$sql_select = " SELECT `terminal_price` FROM `company` WHERE `pk_id` = ".$pk_id." ";
			$result = mysqli_query($conn, $sql_select);
			$row = mysqli_fetch_array($result);
			$arr = array(
				"code" => 1,
				"terminal_price" => $row['terminal_price']
			);
		}else{
			$arr = array(
				"code" => 0,
				"message" => "FAIL"
			);
		}
		$arr = json_encode($arr, JSON_UNESCAPED_UNICODE);
		echo $arr;
	}else if($result == 'a_terminal_calculate'){
		if($conn){
			$j_pk_id = $_POST['j_pk_id'];
			$m_terminal_goout = $_POST['m_terminal_goout'];

			$sql_update = " UPDATE `company` SET `terminal_goout` = ".$m_terminal_goout." WHERE `pk_id` = ".$j_pk_id." ";
			mysqli_query($conn, $sql_update);
			$arr = array(
				"code" => 1,
				"message" => "SUCC"
			);
		}else{
			$arr = array(
				"code" => 0,
				"message" => "FAIL"
			);
		}
		$arr = json_encode($arr, JSON_UNESCAPED_UNICODE);
		echo $arr;
	}

	function strToHex($string){
		$hex = '';
		for ($i=0; $i<strlen($string); $i++){
			$ord = ord($string[$i]);
			$hexCode = dechex($ord);
			$hex .= substr('0'.$hexCode, -2);
		}
		return strToUpper($hex);
	}

	function post($url, $fields){
		$post_field_string = http_build_query($fields, '', '&');
		$ch = curl_init();
		curl_setopt($ch, CURLOPT_URL, $url);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 10);
		curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
		curl_setopt($ch, CURLOPT_POSTFIELDS, $post_field_string);
		curl_setopt($ch, CURLOPT_POST, true);
		$response = curl_exec($ch);
		curl_close ($ch);
		return $response;
	}

	function mysql_new_password($pw) { return strlen($pw)>0?strtoupper('*'.sha1(sha1($pw,true))):($pw=== null?null:''); }
	mysql_close($conn);
?>