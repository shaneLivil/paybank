// 관리자(a_card_history.html)
function a_card_history_append(data){
    var html = '';
    for(var i=0; i<data.length; i++){
        var date = new Date(data[i].insert_time * 1000);
        var time = date.getFullYear().toString() + "-" + (date.getMonth() + 1).toString() + "-" + date.getDate().toString() + " " + date.getHours().toString() + ":" + date.getMinutes().toString() + ":" + date.getSeconds().toString();
        var u_date = new Date(data[i].update_time * 1000);
        var u_time = u_date.getFullYear().toString() + "-" + (u_date.getMonth() + 1).toString() + "-" + u_date.getDate().toString() + " " + u_date.getHours().toString() + ":" + u_date.getMinutes().toString() + ":" + u_date.getSeconds().toString();
        html += '<tr>';
        html += '   <td class="orders-date" style="text-align: center;">'+data[i].card_version+'</td>';
        html += '   <td class="orders-date" style="text-align: center;">'+data[i].pk_id+'</td>';
        html += '   <td class="orders-date" style="text-align: center;">'+data[i].card_number+'</td>';
        html += '   <td class="orders-date" style="text-align: center;">'+data[i].password+'</td>';
        if(data[i].card_color == 'blue'){ html += '   <td class="orders-date" style="text-align: center; color: blue;">색상</td>'; }
        else if(data[i].card_color == 'red'){ html += '   <td class="orders-date" style="text-align: center; color: red;">색상</td>'; }
        else{ html += '   <td class="orders-date" style="text-align: center;">--</td>'; }
        if(data[i].status == 0){ html += '   <td class="orders-date" style="text-align: center;">미지정</td>'; }
        else if(data[i].status == 1){ html += '   <td class="orders-date" style="text-align: center;">지정완료</td>'; }
        else if(data[i].status == 2){ html += '   <td class="orders-date" style="text-align: center;">삭제</td>'; }
        else{ html += '   <td class="orders-date" style="text-align: center;">--</td>'; }
        html += '   <td class="orders-date" style="text-align: center;">'+data[i].company_id+'</td>';
        html += '   <td class="orders-date" style="text-align: center;">'+data[i].company_name+'</td>';
        html += '   <td class="orders-date" style="text-align: center;">'+time+'</td>';
        html += '   <td class="orders-date" style="text-align: center;">'+u_time+'</td>';
        html += '</tr>';
    }
    $('#a_card_history_list').html(html);
}

// 관리자(a_company_list.html)
function a_company_list_append(data){
    var html = '';
    for(var i=0; i<data.length; i++){
        var date = new Date(data[i].insert_time * 1000);
        var time = date.getFullYear().toString() + "-" + (date.getMonth() + 1).toString() + "-" + date.getDate().toString() + " " + date.getHours().toString() + ":" + date.getMinutes().toString() + ":" + date.getSeconds().toString();
        html += '<tr>';
        html += '   <td class="orders-date" style="text-align: center;">--</td>';
        html += '   <td class="orders-date" style="text-align: center;">'+data[i].pk_id+'</td>';
        html += '   <td class="orders-date" style="text-align: center;">'+data[i].company_name+'</td>';
        html += '   <td class="orders-date" style="text-align: center;">'+data[i].company_contact+'</td>';
        html += '   <td class="orders-date" style="text-align: center;">'+data[i].company_number+'</td>'; 
        html += '   <td class="orders-date" style="text-align: center;">'+data[i].card_unit_price+'</td>'; 
        html += '   <td class="orders-date" style="text-align: center;">'+data[i].card_visa_1+'</td>'; 
        html += '   <td class="orders-date" style="text-align: center;">'+data[i].card_visa_2+'</td>'; 
		html += '   <td class="orders-date" style="text-align: center;">'+data[i].terminal_price+'</td>'; 
        html += '   <td class="orders-date" style="text-align: center;">'+time+'</td>';
        html += '   <td class="orders-date" style="text-align: center;">';
        html += '       <button class="btn btn-primary btn-sm" style="padding: .2rem .75rem;" data-toggle="modal" data-target="#modalMembers_2" onclick=set_card('+data[i].pk_id+',"'+data[i].company_name.replace(/ /gi, "")+'");>카드주기</button>';
        html += '       <button class="btn btn-primary btn-sm" style="padding: .2rem .75rem;" data-toggle="modal" data-target="#modalMembers_3" onclick=modif_card('+data[i].pk_id+','+data[i].card_unit_price+','+data[i].card_visa_1+','+data[i].card_visa_2+','+data[i].terminal_price+');>카드단가</button>';
        html += '       <button class="btn btn-primary btn-sm" style="padding: .2rem .75rem;" data-toggle="modal" data-target="#modalMembers_3" onclick=terminal_calculate('+data[i].pk_id+','+data[i].terminal_goout+');>단말기정산</button>';
		html += '   </td>';
        html += '</tr>';
    }
    $('#a_company_list_list').html(html);
}

// 관리자(a_payment_history.html)
function a_payment_history_append(data){
    var html = '';
    for(var i=0; i<data.length; i++){
        var date = new Date(data[i].update_time * 1000);
        var time = date.getFullYear().toString() + "-" + (date.getMonth() + 1).toString() + "-" + date.getDate().toString() + " " + date.getHours().toString() + ":" + date.getMinutes().toString() + ":" + date.getSeconds().toString();
        html += '<tr>';
        html += '   <td class="orders-date" style="text-align: center;">--</td>';
        html += '   <td class="orders-date" style="text-align: center;">'+data[i].company_pk_id+'</td>';
        html += '   <td class="orders-date" style="text-align: center;">'+data[i].company_name+'</td>';
        html += '   <td class="orders-date" style="text-align: center;">'+data[i].company_number+'</td>';
        if(data[i].itemname == 'wallet'){ html += '   <td class="orders-date" style="text-align: center;">월렛카드</td>'; }
		else if(data[i].itemname == 'terminal'){ html += '   <td class="orders-date" style="text-align: center;">단말기</td>'; }
		else if(data[i].itemname == 'visa'){ html += '   <td class="orders-date" style="text-align: center;">VISA카드	</td>'; }
        else{ html += '   <td class="orders-date" style="text-align: center;">--</td>'; }
        if(data[i].card_color == 'blue'){ html += '   <td class="orders-date" style="text-align: center; color: blue;">색상</td>'; }
        else if(data[i].card_color == 'red'){ html += '   <td class="orders-date" style="text-align: center; color: red;">색상</td>'; }
		else if(data[i].card_color == 'black'){ html += '   <td class="orders-date" style="text-align: center;">일반</td>'; }
		else if(data[i].card_color == 'normal'){ html += '   <td class="orders-date" style="text-align: center;">일반</td>'; }
		else if(data[i].card_color == 'silver'){ html += '   <td class="orders-date" style="text-align: center;">은색</td>'; }
		else{ html += '   <td class="orders-date" style="text-align: center;">--</td>'; }
        html += '   <td class="orders-date" style="text-align: center;">'+data[i].card_number+'</td>';
        html += '   <td class="orders-date" style="text-align: center;">'+data[i].price+'</td>';
        html += '   <td class="orders-date" style="text-align: center;">'+data[i].ordernum+'</td>';
        html += '   <td class="orders-date" style="text-align: center;">'+time+'</td>';
        if(data[i].admin_status == 0){ html += '<td class="orders-date" style="text-align: center;"><button class="btn btn-primary btn-sm" style="padding: .2rem .75rem;" onclick=f_issued('+data[i].pk_id+');>발급</button></td>'; }
        else{ html += '<td class="orders-date" style="text-align: center;">발급완료</td>'; }
        html += '</tr>';
    }
    $('#a_payment_history_list').html(html);
}

// 관리자(a_franchisee_list.html)
function a_franchisee_append(data){
    var html = '';
    for(var i=0; i<data.length; i++){
        var i_date = new Date(data[i].insert_time * 1000);
        var i_time = i_date.getFullYear().toString() + "-" + (i_date.getMonth() + 1).toString() + "-" + i_date.getDate().toString() + " " + i_date.getHours().toString() + ":" + i_date.getMinutes().toString() + ":" + i_date.getSeconds().toString();
        var u_date = new Date(data[i].update_time * 1000);
        var u_time = u_date.getFullYear().toString() + "-" + (u_date.getMonth() + 1).toString() + "-" + u_date.getDate().toString() + " " + u_date.getHours().toString() + ":" + u_date.getMinutes().toString() + ":" + u_date.getSeconds().toString();
        html += '<tr>';
        html += '   <td class="orders-date" style="text-align: center;">--</td>';
        html += '   <td class="orders-date" style="text-align: center;">'+data[i].store_id+'</td>';
        html += '   <td class="orders-date" style="text-align: center;">'+data[i].store_name+'</td>';
		html += '   <td class="orders-date" style="text-align: center;">'+data[i].t_status+'</td>';
		html += '   <td class="orders-date" style="text-align: center;">'+data[i].company_name+'</td>';
		html += '   <td class="orders-date" style="text-align: center;">'+data[i].company_contact+'</td>';
		html += '   <td class="orders-date" style="text-align: center;">'+data[i].total_fee+'</td>';
        html += '   <td class="orders-date" style="text-align: center;">'+i_time+'</td>';
        html += '   <td class="orders-date" style="text-align: center;">'+u_time+'</td>';
        if(data[i].status == 2){ html += '   <td class="orders-date" style="text-align: center;">심사합격</td>'; }
        else if(data[i].status == 1){ html += '   <td class="orders-date" style="text-align: center;">심사거절</td>'; }
        else if(data[i].status == 3){
            html += '<td class="orders-date" style="text-align: center;">';
            html += '   <button class="btn btn-primary btn-sm" style="padding: .2rem .75rem;" onclick=judge_succ('+data[i].pk_id+');>심사합격</button>';
            html += '   <button class="btn btn-danger btn-sm" style="padding: .2rem .75rem;" onclick=judge_fail('+data[i].pk_id+');>심사거절</button>';
            html += '</td>';
        }
        else{ html += '   <td class="orders-date" style="text-align: center;">--</td>'; }
        html += '</tr>';
    }
    $('#a_franchisee_list').html(html);
}

// 업체(u_card_history.html)
function u_card_history_append(data){
    var html = '';
    for(var i=0; i<data.length; i++){
        var date = new Date(data[i].insert_time * 1000);
        var time = date.getFullYear().toString() + "-" + (date.getMonth() + 1).toString() + "-" + date.getDate().toString() + " " + date.getHours().toString() + ":" + date.getMinutes().toString() + ":" + date.getSeconds().toString();
        var u_date = new Date(data[i].update_time * 1000);
        var u_time = u_date.getFullYear().toString() + "-" + (u_date.getMonth() + 1).toString() + "-" + u_date.getDate().toString() + " " + u_date.getHours().toString() + ":" + u_date.getMinutes().toString() + ":" + u_date.getSeconds().toString();
        html += '<tr>';
        html += '   <td class="orders-date" style="text-align: center;">'+data[i].card_version+'</td>';
        html += '   <td class="orders-date" style="text-align: center;">'+data[i].card_number+'</td>';
        if(data[i].card_color == 'blue'){ html += '   <td class="orders-date" style="text-align: center; color: blue;">색상</td>'; }
        else if(data[i].card_color == 'red'){ html += '   <td class="orders-date" style="text-align: center; color: red;">색상</td>'; }
        else{ html += '   <td class="orders-date" style="text-align: center;">--</td>'; }
        if(data[i].status == 1){ html += '   <td class="orders-date" style="text-align: center;">미발주</td>'; }
        else if(data[i].status == 2){ html += '   <td class="orders-date" style="text-align: center;">삭제</td>'; }
        else if(data[i].status == 3){ html += '   <td class="orders-date" style="text-align: center;">발주완료</td>'; }
        else{ html += '   <td class="orders-date" style="text-align: center;">--</td>'; }
        html += '   <td class="orders-date" style="text-align: center;">'+time+'</td>';
        html += '   <td class="orders-date" style="text-align: center;">'+u_time+'</td>';
        if(data[i].remarks == "" || data[i].remarks == null) html += '   <td class="orders-date" style="text-align: center;"></td>';
        else html += '   <td class="orders-date" style="text-align: center;">'+data[i].remarks+'</td>';
        html += '   <td class="orders-date" style="text-align: center;">';
        if(data[i].status == 3){ html += '발주완료'; }
        else{ html += '<button class="btn btn-primary btn-sm" style="padding: .2rem .75rem;" data-toggle="modal" data-target="#modalMembers" onclick="placing_order('+data[i].pk_id+')">발주하기</button>'; }
        html += '   </td>';
        html += '</tr>';
    }
    $('#u_card_history_list').html(html);
}

// 업체(u_payment_history.html)
function u_payment_history_append(data){
    var html = '';
    for(var i=0; i<data.length; i++){
        var date = new Date(data[i].update_time * 1000);
        var time = date.getFullYear().toString() + "-" + (date.getMonth() + 1).toString() + "-" + date.getDate().toString() + " " + date.getHours().toString() + ":" + date.getMinutes().toString() + ":" + date.getSeconds().toString();
        html += '<tr>';
        html += '   <td class="orders-date" style="text-align: center;">--</td>';
        if(data[i].itemname == 'wallet'){ html += '   <td class="orders-date" style="text-align: center;">월렛카드</td>'; }
        else if(data[i].itemname == 'visa'){ html += '   <td class="orders-date" style="text-align: center;">VISA카드</td>'; }
		else if(data[i].itemname == 'terminal'){ html += '   <td class="orders-date" style="text-align: center;">단말기</td>'; }
        else{ html += '   <td class="orders-date" style="text-align: center;">--</td>'; }
        if(data[i].card_color == 'blue'){ html += '   <td class="orders-date" style="text-align: center; color: blue;">색상</td>'; }
        else if(data[i].card_color == 'red'){ html += '   <td class="orders-date" style="text-align: center; color: red;">색상</td>'; }
        else if(data[i].card_color == 'silver'){ html += '   <td class="orders-date" style="text-align: center;">은색</td>'; }
        else{ html += '   <td class="orders-date" style="text-align: center;">일반</td>'; }
        html += '   <td class="orders-date" style="text-align: center;">'+data[i].card_number+'</td>';
        html += '   <td class="orders-date" style="text-align: center;">'+data[i].price+'</td>';
        if(data[i].status == 1){ html += '   <td class="orders-date" style="text-align: center;">결제완료</td>'; }
        else if(data[i].status == 0){ html += '   <td class="orders-date" style="text-align: center;">미결제</td>'; }
        else{ html += '   <td class="orders-date" style="text-align: center;">--</td>'; }
        html += '   <td class="orders-date" style="text-align: center;">'+data[i].ordernum+'</td>';
        html += '   <td class="orders-date" style="text-align: center;">'+time+'</td>';
        if(data[i].status == 0){ html += '<td class="orders-date" style="text-align: center;"><button class="btn btn-primary btn-sm" style="padding: .2rem .75rem;" onclick=order_pay('+data[i].pk_id+');>결제</button></td>'; }
        else{ html += '   <td class="orders-date" style="text-align: center;">--</td>'; }
        // else{ html += '<td class="orders-date" style="text-align: center;"><button class="btn btn-primary btn-sm" style="padding: .2rem .75rem;" onclick=set_card('+data[i].pk_id+',"'+data[i].company_name.replace(/ /gi, "")+'");>결제</button></td>'; }
        html += '</tr>';
    }
    $('#u_payment_history_list').html(html);
}

// 업체(u_franchisee_list.html)
function u_franchisee_append(data){
    var html = '';
    for(var i=0; i<data.length; i++){
        var i_date = new Date(data[i].insert_time * 1000);
        var i_time = i_date.getFullYear().toString() + "-" + (i_date.getMonth() + 1).toString() + "-" + i_date.getDate().toString() + " " + i_date.getHours().toString() + ":" + i_date.getMinutes().toString() + ":" + i_date.getSeconds().toString();
        var u_date = new Date(data[i].update_time * 1000);
        var u_time = u_date.getFullYear().toString() + "-" + (u_date.getMonth() + 1).toString() + "-" + u_date.getDate().toString() + " " + u_date.getHours().toString() + ":" + u_date.getMinutes().toString() + ":" + u_date.getSeconds().toString();
        html += '<tr>';
        html += '   <td class="orders-date" style="text-align: center;">--</td>';
        html += '   <td class="orders-date" style="text-align: center;">'+data[i].store_id+'</td>';
        html += '   <td class="orders-date" style="text-align: center;">'+data[i].store_name+'</td>';
        if(data[i].status == 2){ html += '   <td class="orders-date" style="text-align: center;">심사합격</td>'; }
        else if(data[i].status == 1){ html += '   <td class="orders-date" style="text-align: center;">심사거절</td>'; }
        else if(data[i].status == 3){ html += '   <td class="orders-date" style="text-align: center;">심사중...</td>'; }
        else{ html += '   <td class="orders-date" style="text-align: center;">--</td>'; }
		html += '   <td class="orders-date" style="text-align: center;">'+data[i].total_fee+'</td>';
        html += '   <td class="orders-date" style="text-align: center;">'+i_time+'</td>';
        html += '   <td class="orders-date" style="text-align: center;">'+u_time+'</td>';
        html += '   <td class="orders-date" style="text-align: center;">--</td>';
        html += '</tr>';
    }
    $('#u_franchisee_list').html(html);
}

// VISA카드(a_visacard_history.html)
function a_visacard_history_append(data){
    var html = '';
    for(var i=0; i<data.length; i++){
        var date = new Date(data[i].insert_time * 1000);
        var time = date.getFullYear().toString() + "-" + (date.getMonth() + 1).toString() + "-" + date.getDate().toString() + " " + date.getHours().toString() + ":" + date.getMinutes().toString() + ":" + date.getSeconds().toString();
        html += '<tr>';
        html += '   <td class="orders-date" style="text-align: center;">'+data[i].pk_id+'</td>';
        html += '   <td class="orders-date" style="text-align: center;">'+data[i].card_number+'</td>';
        html += '   <td class="orders-date" style="text-align: center;">'+data[i].password+'</td>';
        if(data[i].card_color == 'silver'){ html += '   <td class="orders-date" style="text-align: center">은색</td>'; }
        else if(data[i].card_color == 'normal'){ html += '   <td class="orders-date" style="text-align: center;">일반</td>'; }
        else{ html += '   <td class="orders-date" style="text-align: center;">--</td>'; }
        html += '   <td class="orders-date" style="text-align: center;">'+data[i].end_date1+'/'+data[i].end_date2+'</td>';
        html += '   <td class="orders-date" style="text-align: center;">'+data[i].company_id+'</td>';
        html += '   <td class="orders-date" style="text-align: center;">'+data[i].company_name+'</td>';
        html += '   <td class="orders-date" style="text-align: center;">'+time+'</td>';
        html += '   <td class="orders-date" style="text-align: center;">';
        html += '       <button class="btn btn-primary btn-sm" style="padding: .2rem .75rem;" data-toggle="modal" data-target="#modalMembers2" onclick=visacard_modify('+data[i].pk_id+',"'+data[i].card_number.replace(/ /gi, "")+'","'+data[i].password.replace(/ /gi, "")+'");>수정</button>';
        html += '       <button class="btn btn-danger btn-sm" style="padding: .2rem .75rem;" onclick=visacard_delete('+data[i].pk_id+');>삭제</button>';
        html += '   </td>';
        html += '</tr>';
    }
    $('#a_visacard_history_list').html(html);
}

// VISA카드(u_visacard_history.html)
function u_visacard_history_append(data){
    var html = '';
    for(var i=0; i<data.length; i++){
        var date = new Date(data[i].insert_time * 1000);
        var time = date.getFullYear().toString() + "-" + (date.getMonth() + 1).toString() + "-" + date.getDate().toString() + " " + date.getHours().toString() + ":" + date.getMinutes().toString() + ":" + date.getSeconds().toString();
        html += '<tr>';
        html += '   <td class="orders-date" style="text-align: center;">'+data[i].card_number+'</td>';
        if(data[i].card_color == 'silver'){ html += '   <td class="orders-date" style="text-align: center">은색</td>'; }
        else if(data[i].card_color == 'normal'){ html += '   <td class="orders-date" style="text-align: center;">일반</td>'; }
        else{ html += '   <td class="orders-date" style="text-align: center;">--</td>'; }
        if(data[i].status == 0){ html += '   <td class="orders-date" style="text-align: center;">미발주</td>'; }
        else{ html += '   <td class="orders-date" style="text-align: center;">발주완료</td>'; }
        html += '   <td class="orders-date" style="text-align: center;">'+data[i].end_date1+'/'+data[i].end_date2+'</td>';
        html += '   <td class="orders-date" style="text-align: center;">'+time+'</td>';
        if(data[i].remarks == null){ html += '   <td class="orders-date" style="text-align: center;">--</td>'; }
        else{ html += '   <td class="orders-date" style="text-align: center;">'+data[i].remarks+'</td>'; }
        if(data[i].status == 0){ 
            html += '   <td class="orders-date" style="text-align: center;">';
            html += '       <button class="btn btn-primary btn-sm" style="padding: .2rem .75rem;" data-toggle="modal" data-target="#modalMembers" onclick=order('+data[i].pk_id+');>발주</button>';
            html +- '   </td>'; 
        }else{ 
            html += '   <td class="orders-date" style="text-align: center;">발주완료</td>'; 
        }
        html += '</tr>';
    }
    $('#u_visacard_history_list').html(html);
}