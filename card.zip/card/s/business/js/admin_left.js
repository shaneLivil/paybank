document.writeln('	<nav class="navbar navbar-vertical fixed-left navbar-expand-md " id="sidebar">');
document.writeln('		<div class="container-fluid">');
document.writeln('			<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#sidebarCollapse" aria-controls="sidebarCollapse" aria-expanded="false" aria-label="Toggle navigation">');
document.writeln('				<span class="navbar-toggler-icon"></span>');
document.writeln('			</button>');
document.writeln('		<a class="navbar-brand" href="/"><img src="../../assets/img/livil.svg" class="navbar-brand-img mx-auto" alt=""></a>');
document.writeln('		<div class="navbar-user d-md-none">');
document.writeln('		              <div class="dropdown">');
document.writeln('		                <a href="javascript:logout_left();" class="dropdown-toggle">');
document.writeln('		                 로그아웃');
document.writeln('		                </a>');
document.writeln('		              </div>');
document.writeln('		           </div>');
document.writeln('		<div class="collapse navbar-collapse" id="sidebarCollapse">');
document.writeln('			<ul class="navbar-nav">');
document.writeln('				<li class="nav-item">');
document.writeln('					<a class="nav-link active"><i class="fe fe-credit-card"></i>카드</a>');
document.writeln('					<div class="collapse show">');
document.writeln('						<ul class="nav nav-sm flex-column">');
document.writeln('							<li class="nav-item"><a class="nav-link" href=javascript:left_menu("a_card_history");>웰렛카드</a></li>');
document.writeln('							<li class="nav-item"><a class="nav-link" href=javascript:left_menu("a_visacard_history");>mastercard카드</a></li>');
document.writeln('							<li class="nav-item"><a class="nav-link" href=javascript:left_menu("a_payment_history");>결제내역</a></li>');
document.writeln('						</ul>');
document.writeln('					</div>');
document.writeln('				</li>');
document.writeln('				<li class="nav-item">');
document.writeln('					<a class="nav-link active"><i class="fe fe-users"></i>업체</a>');
document.writeln('					<div class="collapse show">');
document.writeln('						<ul class="nav nav-sm flex-column">');
document.writeln('							<li class="nav-item"><a class="nav-link" href=javascript:left_menu("a_company_list");>업체</a></li>');
document.writeln('							<li class="nav-item"><a class="nav-link" href=javascript:left_menu("a_franchisee_list");>가맹점</a></li>');
document.writeln('						</ul>');
document.writeln('					</div>');
document.writeln('				</li>');
document.writeln('					</ul>');
document.writeln('					<hr class="navbar-divider my-3">');
document.writeln('				</div>');
document.writeln('			</div>');
document.writeln('		</nav>');
document.writeln('		<nav id="sidebarSmall"></nav>');
document.writeln('		<div class="main-content" id="topnav">');
document.writeln('		</div>');

function left_menu(result){
    if(result == "a_card_history"){
        // 카드내역 보기
        location.href="./a_card_history.html";
    }else if(result == "a_company_list"){
		// 업체 리스트
		location.href="./a_company_list.html";
	}else if(result == 'a_payment_history'){
		// 결제내역 보기
		location.href="./a_payment_history.html";
	}else if(result == 'a_franchisee_list'){
		// 가맹점 리스트
		location.href="./a_franchisee_list.html";
	}else if(result == 'a_visacard_history'){
		// 비자카드 리스트
		location.href="./a_visacard_history.html";
	}
}

function logout_left(){
	var data = {
		result: 'logout'
	}

	$.ajax({
		type: 'POST',
		url: '../send_db.php',
		dataType: 'text',
		data: data,
		success: function(data){
			var json_data = JSON.parse(data);
			if(json_data.code == 1){
				location.href="../../index.html";
			}
		},
		error: function(err){
			alert('error: ' + JSON.stringify(err));
		}
	});
}