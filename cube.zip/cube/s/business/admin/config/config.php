<?php 
/**
*  Geetest配置文件
* @author Tanxu
*/
define("CAPTCHA_ID", "b46d1900d0a894591916ea94ea91bd2c");
define("PRIVATE_KEY", "36fc3fe98530eea08dfc6ce76e3d24c4");
define("MOBILE_CAPTCHA_ID", "7c25da6fe21944cfe507d2f9876775a9");
define("MOBILE_PRIVATE_KEY", "f5883f4ee3bd4fa8caec67941de1b903");



 ?>